import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import type { IssueCategory } from '../lib/types';
import { CATEGORY_COLORS } from './StatusChip';

// Fix default leaflet marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

function createColoredIcon(color: string) {
  return L.divIcon({
    html: `<div style="
      width: 24px; height: 24px;
      background: ${color};
      border-radius: 50% 50% 50% 0;
      transform: rotate(-45deg);
      border: 3px solid white;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    "></div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 24],
    className: '',
  });
}

interface Props {
  lat: number;
  lng: number;
  category: IssueCategory;
  title: string;
}

export default function MapView({ lat, lng, category, title }: Props) {
  const color = CATEGORY_COLORS[category];
  const icon = createColoredIcon(color);

  return (
    <Box sx={{ height: '100%', minHeight: 280, borderRadius: 2, overflow: 'hidden' }}>
      <MapContainer
        center={[lat, lng]}
        zoom={15}
        style={{ height: '100%', minHeight: 280, width: '100%' }}
        scrollWheelZoom={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <Marker position={[lat, lng]} icon={icon}>
          <Popup>
            <Typography variant="body2" fontWeight={600}>{title}</Typography>
            <Typography variant="caption" color="text.secondary">{category}</Typography>
          </Popup>
        </Marker>
      </MapContainer>
    </Box>
  );
}
