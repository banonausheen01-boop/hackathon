/*
# AI Civic Guardian — Initial Schema

## Summary
Creates the core tables for the AI Civic Guardian complaint tracking platform.

## New Tables

### profiles
Stores public user profile data synced from auth.users.
- id: UUID primary key, references auth.users(id)
- email: User's email address
- full_name: Display name
- role: 'user' or 'admin' — controls dashboard access
- created_at: Timestamp

### complaints
Stores civic issue complaints submitted by users.
- id: UUID primary key
- user_id: Owner reference to auth.users, defaults to auth.uid()
- title: Short complaint title (auto-generated or user-edited)
- description: Full complaint body (Gemini-generated or user-edited)
- category: One of: Garbage, Pothole, Broken Streetlight, Water Leakage, Road Damage
- status: Workflow state — Pending | In Progress | Resolved
- confidence_score: AI detection confidence (0–1)
- image_url: Public URL of the uploaded image
- latitude / longitude: Optional GPS coords for map view
- location_name: Human-readable location string
- created_at / updated_at: Audit timestamps

## Security
- RLS enabled on both tables
- profiles: owner can read/update their own row; admin role can read all
- complaints: owner CRUD; admin can read/update all (for status management)
- A trigger auto-creates a profile row when a new auth user is inserted

## Notes
1. The `role` column defaults to 'user'. Promote to 'admin' manually or via the admin UI.
2. Complaints are owner-scoped by DEFAULT auth.uid() so inserts never need to pass user_id.
3. Admin policies use a sub-select on profiles to check role — no separate join needed.
*/

-- ============================================================
-- profiles
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

-- Admin can read all profiles
DROP POLICY IF EXISTS "admin_select_profiles" ON profiles;
CREATE POLICY "admin_select_profiles" ON profiles FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'
  ));

-- ============================================================
-- complaints
-- ============================================================
CREATE TABLE IF NOT EXISTS complaints (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  category text NOT NULL CHECK (category IN ('Garbage','Pothole','Broken Streetlight','Water Leakage','Road Damage')),
  status text NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending','In Progress','Resolved')),
  confidence_score numeric(5,4) DEFAULT 0,
  image_url text,
  latitude numeric(10,7),
  longitude numeric(10,7),
  location_name text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS complaints_user_id_idx ON complaints(user_id);
CREATE INDEX IF NOT EXISTS complaints_status_idx ON complaints(status);
CREATE INDEX IF NOT EXISTS complaints_category_idx ON complaints(category);
CREATE INDEX IF NOT EXISTS complaints_created_at_idx ON complaints(created_at DESC);

ALTER TABLE complaints ENABLE ROW LEVEL SECURITY;

-- Owner CRUD
DROP POLICY IF EXISTS "select_own_complaints" ON complaints;
CREATE POLICY "select_own_complaints" ON complaints FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_complaints" ON complaints;
CREATE POLICY "insert_own_complaints" ON complaints FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_complaints" ON complaints;
CREATE POLICY "update_own_complaints" ON complaints FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_complaints" ON complaints;
CREATE POLICY "delete_own_complaints" ON complaints FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Admin can read and update any complaint
DROP POLICY IF EXISTS "admin_select_complaints" ON complaints;
CREATE POLICY "admin_select_complaints" ON complaints FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'
  ));

DROP POLICY IF EXISTS "admin_update_complaints" ON complaints;
CREATE POLICY "admin_update_complaints" ON complaints FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'
  ));

-- ============================================================
-- updated_at trigger
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS complaints_updated_at ON complaints;
CREATE TRIGGER complaints_updated_at
  BEFORE UPDATE ON complaints
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- Auto-create profile on sign-up
-- ============================================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
