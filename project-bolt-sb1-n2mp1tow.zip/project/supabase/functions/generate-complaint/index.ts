import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { category, location, confidence } = await req.json();

    if (!category) {
      return new Response(
        JSON.stringify({ error: "category is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("GEMINI_API_KEY");

    if (!apiKey) {
      const fallback = generateFallbackComplaint(category, location, confidence);
      return new Response(
        JSON.stringify(fallback),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const prompt = `You are a professional civic complaint writer for a municipal authority system.

Generate a formal, professional complaint report for the following civic issue:
- Issue Category: ${category}
- Location: ${location || "Not specified"}
- AI Detection Confidence: ${confidence ? Math.round(confidence * 100) + "%" : "Not specified"}

Return a JSON object with exactly these two fields:
{
  "title": "A concise complaint title (max 80 characters)",
  "description": "A formal 3-4 sentence complaint description that: states the issue clearly, mentions the location, notes the urgency/impact on residents, and requests prompt resolution."
}

Respond with only valid JSON, no markdown, no code blocks.`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { responseMimeType: "application/json", temperature: 0.7 },
        }),
      }
    );

    if (!response.ok) {
      const fallback = generateFallbackComplaint(category, location, confidence);
      return new Response(
        JSON.stringify(fallback),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const geminiData = await response.json();
    const rawText = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!rawText) {
      const fallback = generateFallbackComplaint(category, location, confidence);
      return new Response(
        JSON.stringify(fallback),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const parsed = JSON.parse(rawText);

    return new Response(
      JSON.stringify({ title: parsed.title, description: parsed.description }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function generateFallbackComplaint(
  category: string,
  location: string | undefined,
  confidence: number | undefined
): { title: string; description: string } {
  const loc = location || "the reported area";
  const conf = confidence ? ` (AI confidence: ${Math.round(confidence * 100)}%)` : "";

  const templates: Record<string, { title: string; description: string }> = {
    "Biodegradable Waste": {
      title: `Biodegradable Waste Accumulation at ${loc}`,
      description: `A significant accumulation of biodegradable organic waste — including food scraps, plant matter, and decomposing material — has been detected at ${loc}${conf}. The decomposing waste is producing foul odours and attracting pests, posing serious health hazards to nearby residents. Immediate collection and composting or disposal is required to prevent disease vectors and environmental contamination. We urgently request the sanitation department to attend to this matter at the earliest opportunity.`,
    },
    "Non-Biodegradable Waste": {
      title: `Non-Biodegradable Waste Dumping at ${loc}`,
      description: `Illegal dumping of non-biodegradable solid waste has been identified at ${loc}${conf}. The accumulated materials — including metals, glass, and mixed solid refuse — are creating an eyesore and hazardous obstruction in the public space. This type of waste does not decompose and will persist indefinitely if not removed, causing long-term environmental damage. We request prompt removal and enforcement action against illegal dumping in this area.`,
    },
    "Plastic Waste": {
      title: `Plastic Waste Pollution Reported at ${loc}`,
      description: `A large quantity of plastic waste including bottles, bags, and packaging materials has been detected at ${loc}${conf}. Plastic pollution poses a severe threat to local drainage systems, wildlife, and the environment as it does not biodegrade. The accumulation is blocking public pathways and contributing to waterway contamination. We urgently request immediate collection and request a review of waste management practices to prevent recurrence.`,
    },
    "Electronic Waste": {
      title: `Illegal E-Waste Disposal at ${loc}`,
      description: `Illegally discarded electronic waste — including old appliances, batteries, and electronic components — has been reported at ${loc}${conf}. E-waste contains hazardous materials such as lead, mercury, and cadmium that can leach into soil and groundwater, posing serious environmental and health risks. Immediate collection by certified e-waste disposal authorities is required to prevent contamination. We request urgent action and enforcement against improper e-waste disposal.`,
    },
    "Garbage": {
      title: `Garbage Accumulation Reported at ${loc}`,
      description: `A significant accumulation of mixed garbage has been detected at ${loc}${conf}. The uncollected waste poses serious health and environmental hazards to residents in the vicinity. This issue requires immediate attention from the municipal sanitation department to prevent the spread of disease and maintain neighbourhood hygiene. We respectfully request urgent garbage collection and proper disposal at the earliest opportunity.`,
    },
    "Pothole": {
      title: `Dangerous Pothole Reported at ${loc}`,
      description: `A dangerous pothole has been identified on the roadway at ${loc}${conf}. This road defect poses a significant risk to vehicles, motorcyclists, and pedestrians, potentially causing accidents and vehicle damage. The deteriorating road condition requires prompt attention from the public works department to ensure the safety of all road users. We urgently request road repair and resurfacing to restore safe traffic conditions.`,
    },
    "Broken Streetlight": {
      title: `Non-Functional Streetlight at ${loc}`,
      description: `A broken or non-functional streetlight has been reported at ${loc}${conf}. The absence of adequate street lighting creates safety hazards for pedestrians and motorists during nighttime hours, increasing the risk of accidents and criminal activity. This issue requires prompt attention from the electrical department to restore proper illumination. We request immediate inspection and repair of the streetlight to ensure public safety.`,
    },
    "Water Leakage": {
      title: `Water Leakage Issue Detected at ${loc}`,
      description: `A water leakage issue has been identified at ${loc}${conf}. The uncontrolled water seepage is causing damage to public infrastructure and wasting precious water resources. This issue poses risks to road stability and may affect the foundations of nearby structures if left unaddressed. We urgently request inspection by the water utilities department and prompt repair to prevent further damage and resource wastage.`,
    },
    "Road Damage": {
      title: `Road Surface Damage Reported at ${loc}`,
      description: `Significant road surface damage has been detected at ${loc}${conf}. The deteriorated road condition presents a safety hazard to all commuters, including vehicles, cyclists, and pedestrians. The damage may worsen with continued traffic and adverse weather conditions if not addressed promptly. We request an immediate assessment and repair by the road maintenance department to restore safe driving conditions.`,
    },
  };

  return templates[category] ?? {
    title: `Civic Issue Reported at ${loc}`,
    description: `A civic issue has been detected at ${loc}${conf}. This problem requires urgent attention from the relevant municipal authority to ensure the safety and well-being of local residents. We request prompt action to investigate and resolve this matter. Timely resolution will help maintain the quality of life in the community.`,
  };
}
