export type IssueCategory =
  | 'Biodegradable Waste'
  | 'Non-Biodegradable Waste'
  | 'Plastic Waste'
  | 'Electronic Waste'
  | 'Garbage'
  | 'Pothole'
  | 'Broken Streetlight'
  | 'Water Leakage'
  | 'Road Damage';

export type ComplaintStatus = 'Pending' | 'In Progress' | 'Resolved';

export type UserRole = 'user' | 'admin';

export interface Profile {
  id: string;
  email: string | null;
  full_name: string;
  role: UserRole;
  created_at: string;
}

export interface Complaint {
  id: string;
  user_id: string;
  title: string;
  description: string;
  category: IssueCategory;
  status: ComplaintStatus;
  confidence_score: number;
  image_url: string | null;
  latitude: number | null;
  longitude: number | null;
  location_name: string;
  created_at: string;
  updated_at: string;
  profiles?: Profile;
}

export interface AIDetectionResult {
  category: IssueCategory;
  confidence: number;
  allScores: Record<IssueCategory, number>;
}

export interface ComplaintGenerationResult {
  title: string;
  description: string;
}
