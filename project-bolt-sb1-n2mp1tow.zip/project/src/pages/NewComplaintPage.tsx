import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Alert from '@mui/material/Alert';
import CircularProgress from '@mui/material/CircularProgress';
import LinearProgress from '@mui/material/LinearProgress';
import Chip from '@mui/material/Chip';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Grid from '@mui/material/Grid';
import CloudUploadOutlinedIcon from '@mui/icons-material/CloudUploadOutlined';
import AutoFixHighIcon from '@mui/icons-material/AutoFixHigh';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import SendIcon from '@mui/icons-material/Send';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { supabase, STORAGE_BUCKET, getImageUrl } from '../lib/supabase';
import { detectIssueFromImage, generateComplaint } from '../lib/aiDetection';
import { useAuth } from '../hooks/useAuth';
import type { IssueCategory } from '../lib/types';
import { CATEGORY_COLORS } from '../components/StatusChip';

const CATEGORIES: IssueCategory[] = [
  'Biodegradable Waste',
  'Non-Biodegradable Waste',
  'Plastic Waste',
  'Electronic Waste',
  'Garbage',
  'Pothole',
  'Broken Streetlight',
  'Water Leakage',
  'Road Damage',
];

const STEPS = ['Upload Image', 'AI Analysis', 'Review & Submit'];

export default function NewComplaintPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeStep, setActiveStep] = useState(0);

  // Image
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const [detecting, setDetecting] = useState(false);
  const [detectedCategory, setDetectedCategory] = useState<IssueCategory>('Garbage');
  const [confidence, setConfidence] = useState(0);
  const [allScores, setAllScores] = useState<Record<IssueCategory, number> | null>(null);

  // Complaint form
  const [generating, setGenerating] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<IssueCategory>('Garbage');
  const [locationName, setLocationName] = useState('');
  const [latitude, setLatitude] = useState<string>('');
  const [longitude, setLongitude] = useState<string>('');

  // Submission
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function processFile(file: File) {
    if (!file.type.startsWith('image/')) {
      setError('Please upload a valid image file.');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('Image must be under 10 MB.');
      return;
    }
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = (e) => setImagePreview(e.target?.result as string);
    reader.readAsDataURL(file);
    setError(null);
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  }

  async function runDetection() {
    if (!imageFile) return;
    setDetecting(true);
    setActiveStep(1);
    try {
      const result = await detectIssueFromImage(imageFile);
      setDetectedCategory(result.category);
      setCategory(result.category);
      setConfidence(result.confidence);
      setAllScores(result.allScores);
      // Auto-generate complaint
      setGenerating(true);
      const generated = await generateComplaint(result.category, locationName, result.confidence);
      setTitle(generated.title);
      setDescription(generated.description);
      setGenerating(false);
      setActiveStep(2);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Detection failed');
    } finally {
      setDetecting(false);
    }
  }

  async function handleGetLocation() {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(String(pos.coords.latitude.toFixed(6)));
        setLongitude(String(pos.coords.longitude.toFixed(6)));
      },
      () => setError('Could not get your location. Please enter it manually.')
    );
  }

  async function handleSubmit() {
    if (!user || !title || !description) return;
    setSubmitting(true);
    setError(null);

    try {
      let imageUrl: string | null = null;

      if (imageFile) {
        const ext = imageFile.name.split('.').pop();
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from(STORAGE_BUCKET)
          .upload(path, imageFile, { upsert: false });
        if (uploadError) throw new Error(`Image upload failed: ${uploadError.message}`);
        imageUrl = getImageUrl(path);
      }

      const { error: insertError } = await supabase.from('complaints').insert({
        title,
        description,
        category,
        status: 'Pending',
        confidence_score: confidence,
        image_url: imageUrl,
        latitude: latitude ? parseFloat(latitude) : null,
        longitude: longitude ? parseFloat(longitude) : null,
        location_name: locationName,
      });

      if (insertError) throw new Error(insertError.message);
      navigate('/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Submission failed');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Box sx={{ maxWidth: 760, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
        <IconButton onClick={() => navigate('/dashboard')} size="small">
          <ArrowBackIcon />
        </IconButton>
        <Box>
          <Typography variant="h5" fontWeight={700}>
            Report a Civic Issue
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Upload a photo — AI will detect and describe the problem
          </Typography>
        </Box>
      </Box>

      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {STEPS.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Step 0: Upload */}
      {activeStep === 0 && (
        <Card elevation={0}>
          <CardContent sx={{ p: 3 }}>
            <Box
              onDrop={handleDrop}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onClick={() => !imagePreview && fileInputRef.current?.click()}
              sx={{
                border: '2px dashed',
                borderColor: dragOver ? 'primary.main' : imagePreview ? 'success.main' : 'divider',
                borderRadius: 3,
                p: 4,
                textAlign: 'center',
                cursor: imagePreview ? 'default' : 'pointer',
                bgcolor: dragOver ? 'primary.main' + '08' : 'background.default',
                transition: 'all 0.2s',
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              {imagePreview ? (
                <Box>
                  <Box
                    component="img"
                    src={imagePreview}
                    alt="Preview"
                    sx={{ maxHeight: 300, maxWidth: '100%', borderRadius: 2, objectFit: 'contain' }}
                  />
                  <Box sx={{ mt: 1 }}>
                    <Chip
                      label={imageFile?.name}
                      size="small"
                      onDelete={() => { setImageFile(null); setImagePreview(null); setActiveStep(0); }}
                      deleteIcon={<DeleteOutlineIcon />}
                    />
                  </Box>
                </Box>
              ) : (
                <Box>
                  <CloudUploadOutlinedIcon sx={{ fontSize: 56, color: 'text.disabled', mb: 1 }} />
                  <Typography variant="h6" fontWeight={600} color="text.secondary">
                    Drop your image here
                  </Typography>
                  <Typography variant="body2" color="text.disabled">
                    or click to browse — JPG, PNG, WEBP up to 10 MB
                  </Typography>
                </Box>
              )}
            </Box>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              hidden
              onChange={(e) => { const f = e.target.files?.[0]; if (f) processFile(f); }}
            />

            {imagePreview && (
              <Box sx={{ mt: 2 }}>
                <TextField
                  label="Location (optional)"
                  fullWidth
                  value={locationName}
                  onChange={(e) => setLocationName(e.target.value)}
                  placeholder="e.g. Main Street, Downtown"
                  InputProps={{
                    startAdornment: (
                      <Box sx={{ display: 'flex', mr: 1 }}>
                        <LocationOnOutlinedIcon sx={{ color: 'text.secondary', fontSize: 20 }} />
                      </Box>
                    ),
                    endAdornment: (
                      <Button size="small" onClick={handleGetLocation} sx={{ whiteSpace: 'nowrap' }}>
                        Use GPS
                      </Button>
                    ),
                  }}
                />
                <Button
                  variant="contained"
                  fullWidth
                  size="large"
                  onClick={runDetection}
                  startIcon={<AutoFixHighIcon />}
                  sx={{ mt: 2 }}
                >
                  Analyze with AI
                </Button>
              </Box>
            )}

            {!imagePreview && (
              <Button
                variant="outlined"
                fullWidth
                size="large"
                onClick={() => fileInputRef.current?.click()}
                startIcon={<CloudUploadOutlinedIcon />}
                sx={{ mt: 2 }}
              >
                Choose Image
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 1: Detecting */}
      {activeStep === 1 && (
        <Card elevation={0}>
          <CardContent sx={{ p: 3, textAlign: 'center' }}>
            {detecting && (
              <Box>
                <CircularProgress size={56} thickness={3} sx={{ mb: 2 }} />
                <Typography variant="h6" fontWeight={600}>
                  Analyzing Image...
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  AI is detecting the civic issue
                </Typography>
                <LinearProgress sx={{ mt: 2, borderRadius: 2 }} />
              </Box>
            )}
            {generating && !detecting && (
              <Box>
                <AutoFixHighIcon sx={{ fontSize: 56, color: 'primary.main', mb: 2 }} />
                <Typography variant="h6" fontWeight={600}>
                  Generating Complaint...
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  AI is writing a professional complaint
                </Typography>
                <LinearProgress sx={{ mt: 2, borderRadius: 2 }} />
              </Box>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 2: Review */}
      {activeStep === 2 && (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {/* Detection Results */}
          <Card elevation={0}>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <CheckCircleIcon sx={{ color: 'success.main' }} />
                <Typography variant="subtitle1" fontWeight={700}>
                  AI Detection Results
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', mb: 2 }}>
                <Box
                  sx={{
                    flex: 1,
                    minWidth: 120,
                    p: 2,
                    bgcolor: CATEGORY_COLORS[detectedCategory] + '12',
                    borderRadius: 2,
                    border: '1px solid',
                    borderColor: CATEGORY_COLORS[detectedCategory] + '30',
                    textAlign: 'center',
                  }}
                >
                  <Typography variant="caption" color="text.secondary">
                    Detected Issue
                  </Typography>
                  <Typography
                    variant="subtitle1"
                    fontWeight={700}
                    sx={{ color: CATEGORY_COLORS[detectedCategory] }}
                  >
                    {detectedCategory}
                  </Typography>
                </Box>
                <Box
                  sx={{
                    flex: 1,
                    minWidth: 120,
                    p: 2,
                    bgcolor: 'primary.main' + '12',
                    borderRadius: 2,
                    border: '1px solid',
                    borderColor: 'primary.main' + '30',
                    textAlign: 'center',
                  }}
                >
                  <Typography variant="caption" color="text.secondary">
                    Confidence
                  </Typography>
                  <Typography variant="subtitle1" fontWeight={700} color="primary.main">
                    {Math.round(confidence * 100)}%
                  </Typography>
                </Box>
              </Box>
              {allScores && (
                <Box>
                  <Typography variant="caption" color="text.secondary" sx={{ mb: 1, display: 'block' }}>
                    All Category Scores
                  </Typography>
                  {CATEGORIES.map((cat) => (
                    <Box key={cat} sx={{ mb: 0.75 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.25 }}>
                        <Typography variant="caption" fontWeight={cat === detectedCategory ? 700 : 400}>
                          {cat}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {Math.round(allScores[cat] * 100)}%
                        </Typography>
                      </Box>
                      <LinearProgress
                        variant="determinate"
                        value={allScores[cat] * 100}
                        sx={{
                          height: 5,
                          borderRadius: 2,
                          bgcolor: CATEGORY_COLORS[cat] + '20',
                          '& .MuiLinearProgress-bar': { bgcolor: CATEGORY_COLORS[cat] },
                        }}
                      />
                    </Box>
                  ))}
                </Box>
              )}
            </CardContent>
          </Card>

          {/* Complaint Form */}
          <Card elevation={0}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                Edit Complaint Details
              </Typography>
              <Grid container spacing={2}>
                <Grid size={12}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Issue Category</InputLabel>
                    <Select
                      label="Issue Category"
                      value={category}
                      onChange={(e) => setCategory(e.target.value as IssueCategory)}
                    >
                      {CATEGORIES.map((c) => (
                        <MenuItem key={c} value={c}>{c}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid size={12}>
                  <TextField
                    label="Complaint Title"
                    fullWidth
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </Grid>
                <Grid size={12}>
                  <TextField
                    label="Description"
                    fullWidth
                    multiline
                    rows={5}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    required
                  />
                </Grid>
                <Grid size={12}>
                  <TextField
                    label="Location Name"
                    fullWidth
                    value={locationName}
                    onChange={(e) => setLocationName(e.target.value)}
                    placeholder="e.g. 5th Avenue, Block 3"
                  />
                </Grid>
                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField
                    label="Latitude (optional)"
                    fullWidth
                    value={latitude}
                    onChange={(e) => setLatitude(e.target.value)}
                    type="number"
                    inputProps={{ step: 'any' }}
                  />
                </Grid>
                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField
                    label="Longitude (optional)"
                    fullWidth
                    value={longitude}
                    onChange={(e) => setLongitude(e.target.value)}
                    type="number"
                    inputProps={{ step: 'any' }}
                  />
                </Grid>
              </Grid>

              <Divider sx={{ my: 2 }} />

              <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
                <Button variant="outlined" onClick={() => navigate('/dashboard')}>
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  onClick={handleSubmit}
                  disabled={submitting || !title || !description}
                  startIcon={submitting ? <CircularProgress size={16} color="inherit" /> : <SendIcon />}
                >
                  {submitting ? 'Submitting...' : 'Submit Complaint'}
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Box>
      )}
    </Box>
  );
}
