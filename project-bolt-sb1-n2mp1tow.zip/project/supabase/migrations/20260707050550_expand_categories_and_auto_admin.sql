-- Expand category constraint to include garbage subtypes
ALTER TABLE complaints DROP CONSTRAINT IF EXISTS complaints_category_check;
ALTER TABLE complaints ADD CONSTRAINT complaints_category_check CHECK (
  category IN (
    'Biodegradable Waste',
    'Non-Biodegradable Waste',
    'Plastic Waste',
    'Electronic Waste',
    'Garbage',
    'Pothole',
    'Broken Streetlight',
    'Water Leakage',
    'Road Damage'
  )
);

-- Auto-promote specific admin emails on new user creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  admin_emails text[] := ARRAY[
    'ks2007hg@gmail.com',
    'newuser@civicguardian.app'
  ];
  assigned_role text := 'user';
BEGIN
  IF NEW.email = ANY(admin_emails) THEN
    assigned_role := 'admin';
  END IF;

  INSERT INTO profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', SPLIT_PART(COALESCE(NEW.email, ''), '@', 1), ''),
    assigned_role
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    role = CASE
      WHEN NEW.email = ANY(admin_emails) THEN 'admin'
      ELSE profiles.role
    END;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Also ensure existing admin emails already have their role set
UPDATE profiles SET role = 'admin'
WHERE email IN ('ks2007hg@gmail.com', 'newuser@civicguardian.app');
