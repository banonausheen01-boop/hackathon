import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TablePagination from '@mui/material/TablePagination';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Alert from '@mui/material/Alert';
import Skeleton from '@mui/material/Skeleton';
import Grid from '@mui/material/Grid';
import Avatar from '@mui/material/Avatar';
import LinearProgress from '@mui/material/LinearProgress';
import InputAdornment from '@mui/material/InputAdornment';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Chip from '@mui/material/Chip';
import SearchIcon from '@mui/icons-material/Search';
import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
import PendingOutlinedIcon from '@mui/icons-material/PendingOutlined';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import PeopleOutlineIcon from '@mui/icons-material/PeopleOutline';
import BarChartIcon from '@mui/icons-material/BarChart';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import PersonIcon from '@mui/icons-material/Person';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import Button from '@mui/material/Button';
import CircularProgress from '@mui/material/CircularProgress';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { StatusChip, CategoryChip, CATEGORY_COLORS } from '../components/StatusChip';
import type { Complaint, ComplaintStatus, IssueCategory, Profile } from '../lib/types';

const CATEGORIES: (IssueCategory | 'All')[] = [
  'All',
  'Biodegradable Waste',
  'Non-Biodegradable Waste',
  'Plastic Waste',
  'Electronic Waste',
  'Garbage',
  'Pothole',
  'Broken Streetlight',
  'Water Leakage',
  'Road Damage',
];
const STATUSES: (ComplaintStatus | 'All')[] = ['All', 'Pending', 'In Progress', 'Resolved'];

export default function AdminDashboardPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState(0);

  // Complaints state
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [complaintsLoading, setComplaintsLoading] = useState(true);
  const [complaintsError, setComplaintsError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState<IssueCategory | 'All'>('All');
  const [filterStatus, setFilterStatus] = useState<ComplaintStatus | 'All'>('All');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingComplaint, setDeletingComplaint] = useState<Complaint | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Users state
  const [users, setUsers] = useState<Profile[]>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [usersError, setUsersError] = useState<string | null>(null);
  const [userSearch, setUserSearch] = useState('');
  const [updatingUserId, setUpdatingUserId] = useState<string | null>(null);
  const [roleDialogOpen, setRoleDialogOpen] = useState(false);
  const [roleTargetUser, setRoleTargetUser] = useState<Profile | null>(null);

  useEffect(() => {
    loadComplaints();
  }, []);

  useEffect(() => {
    if (activeTab === 1 && users.length === 0) {
      loadUsers();
    }
  }, [activeTab]);

  async function loadComplaints() {
    setComplaintsLoading(true);
    const { data, error } = await supabase
      .from('complaints')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) setComplaintsError(error.message);
    else setComplaints(data ?? []);
    setComplaintsLoading(false);
  }

  async function loadUsers() {
    setUsersLoading(true);
    setUsersError(null);
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) setUsersError(error.message);
    else setUsers(data ?? []);
    setUsersLoading(false);
  }

  async function updateStatus(id: string, status: ComplaintStatus) {
    setUpdatingId(id);
    const { error } = await supabase
      .from('complaints')
      .update({ status })
      .eq('id', id);
    if (!error) {
      setComplaints((prev) => prev.map((c) => (c.id === id ? { ...c, status } : c)));
    }
    setUpdatingId(null);
  }

  function openDeleteDialog(complaint: Complaint) {
    setDeletingComplaint(complaint);
    setDeleteDialogOpen(true);
  }

  async function handleDelete() {
    if (!deletingComplaint) return;
    setDeleting(true);
    const { error } = await supabase
      .from('complaints')
      .delete()
      .eq('id', deletingComplaint.id);
    if (!error) {
      setComplaints((prev) => prev.filter((c) => c.id !== deletingComplaint.id));
    }
    setDeleting(false);
    setDeleteDialogOpen(false);
    setDeletingComplaint(null);
  }

  function openRoleDialog(profile: Profile) {
    setRoleTargetUser(profile);
    setRoleDialogOpen(true);
  }

  async function handleToggleRole() {
    if (!roleTargetUser) return;
    const newRole = roleTargetUser.role === 'admin' ? 'user' : 'admin';
    setUpdatingUserId(roleTargetUser.id);
    const { error } = await supabase
      .from('profiles')
      .update({ role: newRole })
      .eq('id', roleTargetUser.id);
    if (!error) {
      setUsers((prev) =>
        prev.map((u) => (u.id === roleTargetUser.id ? { ...u, role: newRole } : u))
      );
    }
    setUpdatingUserId(null);
    setRoleDialogOpen(false);
    setRoleTargetUser(null);
  }

  const filtered = complaints.filter((c) => {
    const matchSearch =
      !search ||
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.description.toLowerCase().includes(search.toLowerCase()) ||
      c.location_name.toLowerCase().includes(search.toLowerCase());
    const matchCategory = filterCategory === 'All' || c.category === filterCategory;
    const matchStatus = filterStatus === 'All' || c.status === filterStatus;
    return matchSearch && matchCategory && matchStatus;
  });

  const paginated = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  const filteredUsers = users.filter((u) =>
    !userSearch ||
    u.full_name.toLowerCase().includes(userSearch.toLowerCase()) ||
    (u.email ?? '').toLowerCase().includes(userSearch.toLowerCase())
  );

  const stats = {
    total: complaints.length,
    pending: complaints.filter((c) => c.status === 'Pending').length,
    inProgress: complaints.filter((c) => c.status === 'In Progress').length,
    resolved: complaints.filter((c) => c.status === 'Resolved').length,
    uniqueUsers: new Set(complaints.map((c) => c.user_id)).size,
  };

  const categoryStats = CATEGORIES.filter((c) => c !== 'All').map((cat) => ({
    name: cat as IssueCategory,
    count: complaints.filter((c) => c.category === cat).length,
  })).sort((a, b) => b.count - a.count);

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Typography variant="h5" fontWeight={700}>
          Admin Dashboard
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Manage all civic complaints and users across the platform
        </Typography>
      </Box>

      {/* Stats Row */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {[
          { label: 'Total', value: stats.total, icon: <AssignmentOutlinedIcon />, color: '#1a6b5c' },
          { label: 'Pending', value: stats.pending, icon: <PendingOutlinedIcon />, color: '#e65100' },
          { label: 'In Progress', value: stats.inProgress, icon: <AutorenewIcon />, color: '#0288d1' },
          { label: 'Resolved', value: stats.resolved, icon: <CheckCircleOutlineIcon />, color: '#2e7d32' },
          { label: 'Users', value: stats.uniqueUsers, icon: <PeopleOutlineIcon />, color: '#7b1fa2' },
        ].map((s) => (
          <Grid size={{ xs: 6, sm: 4, md: 2.4 }} key={s.label}>
            <Card elevation={0}>
              <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                  <Avatar sx={{ bgcolor: s.color + '18', color: s.color, width: 40, height: 40 }}>
                    {s.icon}
                  </Avatar>
                  <Box>
                    <Typography variant="h5" fontWeight={700} color={s.color}>
                      {complaintsLoading ? <Skeleton width={28} /> : s.value}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {s.label}
                    </Typography>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Tabs */}
      <Card elevation={0} sx={{ mb: 2 }}>
        <Tabs
          value={activeTab}
          onChange={(_, v) => setActiveTab(v)}
          sx={{ px: 2, borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab
            label={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <AssignmentOutlinedIcon fontSize="small" />
                Complaints
              </Box>
            }
          />
          <Tab
            label={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <PeopleOutlineIcon fontSize="small" />
                User Management
              </Box>
            }
          />
        </Tabs>
      </Card>

      {/* Tab 0: Complaints */}
      {activeTab === 0 && (
        <>
          <Grid container spacing={2} sx={{ mb: 3 }}>
            {/* Category Breakdown */}
            <Grid size={{ xs: 12, md: 5 }}>
              <Card elevation={0} sx={{ height: '100%' }}>
                <CardContent sx={{ p: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                    <BarChartIcon sx={{ color: 'primary.main' }} />
                    <Typography variant="subtitle1" fontWeight={700}>
                      Issues by Category
                    </Typography>
                  </Box>
                  {complaintsLoading ? (
                    Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} height={36} sx={{ mb: 0.5 }} />)
                  ) : (
                    categoryStats.map(({ name, count }) => (
                      <Box key={name} sx={{ mb: 1.5 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="body2" fontWeight={600}>{name}</Typography>
                          <Typography variant="body2" color="text.secondary">{count}</Typography>
                        </Box>
                        <LinearProgress
                          variant="determinate"
                          value={stats.total > 0 ? (count / stats.total) * 100 : 0}
                          sx={{
                            height: 7,
                            borderRadius: 4,
                            bgcolor: CATEGORY_COLORS[name] + '20',
                            '& .MuiLinearProgress-bar': { bgcolor: CATEGORY_COLORS[name] },
                          }}
                        />
                      </Box>
                    ))
                  )}
                </CardContent>
              </Card>
            </Grid>

            {/* Status Breakdown */}
            <Grid size={{ xs: 12, md: 7 }}>
              <Card elevation={0} sx={{ height: '100%' }}>
                <CardContent sx={{ p: 3 }}>
                  <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                    Resolution Rate
                  </Typography>
                  {complaintsLoading ? (
                    <Skeleton variant="rectangular" height={120} />
                  ) : (
                    <Box>
                      <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
                        <Card elevation={0} sx={{ flex: 1, minWidth: 100, bgcolor: '#ff980010', border: '1px solid #ff980030', p: 1.5, borderRadius: 2 }}>
                          <Typography variant="h5" fontWeight={700} color="warning.main">{stats.pending}</Typography>
                          <Typography variant="caption" color="text.secondary">Pending</Typography>
                        </Card>
                        <Card elevation={0} sx={{ flex: 1, minWidth: 100, bgcolor: '#2196f310', border: '1px solid #2196f330', p: 1.5, borderRadius: 2 }}>
                          <Typography variant="h5" fontWeight={700} color="info.main">{stats.inProgress}</Typography>
                          <Typography variant="caption" color="text.secondary">In Progress</Typography>
                        </Card>
                        <Card elevation={0} sx={{ flex: 1, minWidth: 100, bgcolor: '#4caf5010', border: '1px solid #4caf5030', p: 1.5, borderRadius: 2 }}>
                          <Typography variant="h5" fontWeight={700} color="success.main">{stats.resolved}</Typography>
                          <Typography variant="caption" color="text.secondary">Resolved</Typography>
                        </Card>
                      </Box>
                      {stats.total > 0 && (
                        <>
                          <Typography variant="caption" color="text.secondary" sx={{ mb: 0.5, display: 'block' }}>
                            Overall Resolution Rate: {Math.round((stats.resolved / stats.total) * 100)}%
                          </Typography>
                          <Box sx={{ display: 'flex', borderRadius: 2, overflow: 'hidden', height: 16 }}>
                            <Box sx={{ flex: stats.resolved, bgcolor: 'success.main', transition: 'flex 0.5s' }} />
                            <Box sx={{ flex: stats.inProgress, bgcolor: 'info.main', transition: 'flex 0.5s' }} />
                            <Box sx={{ flex: stats.pending, bgcolor: 'warning.main', transition: 'flex 0.5s' }} />
                          </Box>
                          <Box sx={{ display: 'flex', gap: 2, mt: 0.5 }}>
                            {[['Resolved', 'success.main'], ['In Progress', 'info.main'], ['Pending', 'warning.main']].map(([label, color]) => (
                              <Box key={label} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: color }} />
                                <Typography variant="caption" color="text.secondary">{label}</Typography>
                              </Box>
                            ))}
                          </Box>
                        </>
                      )}
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Complaints Table */}
          <Card elevation={0}>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2, flexWrap: 'wrap' }}>
                <Typography variant="subtitle1" fontWeight={700} sx={{ flex: '1 1 auto' }}>
                  All Complaints
                </Typography>
                <TextField
                  placeholder="Search title, description, location..."
                  size="small"
                  value={search}
                  onChange={(e) => { setSearch(e.target.value); setPage(0); }}
                  sx={{ width: 260 }}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon sx={{ fontSize: 18 }} />
                      </InputAdornment>
                    ),
                  }}
                />
                <FormControl size="small" sx={{ minWidth: 130 }}>
                  <InputLabel>Category</InputLabel>
                  <Select
                    label="Category"
                    value={filterCategory}
                    onChange={(e) => { setFilterCategory(e.target.value as IssueCategory | 'All'); setPage(0); }}
                  >
                    {CATEGORIES.map((c) => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                  </Select>
                </FormControl>
                <FormControl size="small" sx={{ minWidth: 130 }}>
                  <InputLabel>Status</InputLabel>
                  <Select
                    label="Status"
                    value={filterStatus}
                    onChange={(e) => { setFilterStatus(e.target.value as ComplaintStatus | 'All'); setPage(0); }}
                  >
                    {STATUSES.map((s) => <MenuItem key={s} value={s}>{s}</MenuItem>)}
                  </Select>
                </FormControl>
              </Box>

              {complaintsError && <Alert severity="error" sx={{ mb: 2 }}>{complaintsError}</Alert>}

              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Complaint</TableCell>
                      <TableCell>Category</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>AI Score</TableCell>
                      <TableCell>Date</TableCell>
                      <TableCell>Update Status</TableCell>
                      <TableCell>Delete</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {complaintsLoading ? (
                      Array.from({ length: 6 }).map((_, i) => (
                        <TableRow key={i}>
                          {Array.from({ length: 7 }).map((_, j) => (
                            <TableCell key={j}><Skeleton height={22} /></TableCell>
                          ))}
                        </TableRow>
                      ))
                    ) : paginated.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                          <AssignmentOutlinedIcon sx={{ fontSize: 36, color: 'text.disabled', display: 'block', mx: 'auto', mb: 1 }} />
                          <Typography variant="body2" color="text.secondary">
                            No complaints match your filters
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ) : (
                      paginated.map((c) => (
                        <TableRow key={c.id} hover>
                          <TableCell sx={{ maxWidth: 240 }}>
                            <Typography variant="body2" fontWeight={600} noWrap>
                              {c.title}
                            </Typography>
                            <Typography variant="caption" color="text.secondary" noWrap sx={{ display: 'block' }}>
                              {c.location_name || '—'}
                            </Typography>
                          </TableCell>
                          <TableCell><CategoryChip category={c.category} /></TableCell>
                          <TableCell><StatusChip status={c.status} /></TableCell>
                          <TableCell>
                            {c.confidence_score > 0 ? (
                              <Typography variant="caption" fontWeight={700} color="primary.main">
                                {Math.round(c.confidence_score * 100)}%
                              </Typography>
                            ) : '—'}
                          </TableCell>
                          <TableCell>
                            <Typography variant="caption" color="text.secondary">
                              {new Date(c.created_at).toLocaleDateString()}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <FormControl size="small" sx={{ minWidth: 120 }}>
                              <Select
                                value={c.status}
                                onChange={(e) => updateStatus(c.id, e.target.value as ComplaintStatus)}
                                disabled={updatingId === c.id}
                                sx={{ fontSize: '0.75rem' }}
                              >
                                <MenuItem value="Pending">Pending</MenuItem>
                                <MenuItem value="In Progress">In Progress</MenuItem>
                                <MenuItem value="Resolved">Resolved</MenuItem>
                              </Select>
                            </FormControl>
                          </TableCell>
                          <TableCell>
                            <Tooltip title="Delete complaint">
                              <IconButton
                                size="small"
                                color="error"
                                onClick={() => openDeleteDialog(c)}
                              >
                                <DeleteOutlineIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TableContainer>

              <TablePagination
                component="div"
                count={filtered.length}
                page={page}
                onPageChange={(_, newPage) => setPage(newPage)}
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={(e) => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
                rowsPerPageOptions={[5, 10, 25, 50]}
              />
            </CardContent>
          </Card>
        </>
      )}

      {/* Tab 1: User Management */}
      {activeTab === 1 && (
        <Card elevation={0}>
          <CardContent sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3, flexWrap: 'wrap' }}>
              <Box sx={{ flex: 1 }}>
                <Typography variant="subtitle1" fontWeight={700}>
                  User Management
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Promote users to admin or remove their admin access
                </Typography>
              </Box>
              <TextField
                placeholder="Search by name or email..."
                size="small"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                sx={{ width: 260 }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon sx={{ fontSize: 18 }} />
                    </InputAdornment>
                  ),
                }}
              />
            </Box>

            {usersError && <Alert severity="error" sx={{ mb: 2 }}>{usersError}</Alert>}

            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>User</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Role</TableCell>
                    <TableCell>Joined</TableCell>
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {usersLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <TableRow key={i}>
                        {Array.from({ length: 5 }).map((_, j) => (
                          <TableCell key={j}><Skeleton height={22} /></TableCell>
                        ))}
                      </TableRow>
                    ))
                  ) : filteredUsers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} align="center" sx={{ py: 4 }}>
                        <PeopleOutlineIcon sx={{ fontSize: 36, color: 'text.disabled', display: 'block', mx: 'auto', mb: 1 }} />
                        <Typography variant="body2" color="text.secondary">
                          No users found
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredUsers.map((u) => {
                      const isCurrentUser = u.id === user?.id;
                      return (
                        <TableRow key={u.id} hover>
                          <TableCell>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                              <Avatar
                                sx={{
                                  width: 32,
                                  height: 32,
                                  fontSize: 13,
                                  fontWeight: 700,
                                  bgcolor: u.role === 'admin' ? 'secondary.main' : 'primary.main',
                                }}
                              >
                                {u.full_name?.[0]?.toUpperCase() || '?'}
                              </Avatar>
                              <Box>
                                <Typography variant="body2" fontWeight={600}>
                                  {u.full_name || '—'}
                                </Typography>
                                {isCurrentUser && (
                                  <Typography variant="caption" color="primary.main" fontWeight={600}>
                                    (You)
                                  </Typography>
                                )}
                              </Box>
                            </Box>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary">
                              {u.email || '—'}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={u.role === 'admin' ? 'Admin' : 'User'}
                              size="small"
                              color={u.role === 'admin' ? 'secondary' : 'default'}
                              icon={u.role === 'admin' ? <AdminPanelSettingsIcon /> : <PersonIcon />}
                              sx={{ fontWeight: 700, fontSize: '0.72rem' }}
                            />
                          </TableCell>
                          <TableCell>
                            <Typography variant="caption" color="text.secondary">
                              {new Date(u.created_at).toLocaleDateString()}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Tooltip title={isCurrentUser ? "Can't change your own role" : u.role === 'admin' ? 'Remove admin access' : 'Promote to admin'}>
                              <span>
                                <Button
                                  size="small"
                                  variant="outlined"
                                  color={u.role === 'admin' ? 'error' : 'primary'}
                                  onClick={() => openRoleDialog(u)}
                                  disabled={isCurrentUser || updatingUserId === u.id}
                                  startIcon={updatingUserId === u.id ? <CircularProgress size={12} /> : u.role === 'admin' ? <PersonIcon /> : <AdminPanelSettingsIcon />}
                                  sx={{ fontSize: '0.72rem', whiteSpace: 'nowrap' }}
                                >
                                  {u.role === 'admin' ? 'Remove Admin' : 'Make Admin'}
                                </Button>
                              </span>
                            </Tooltip>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)}>
        <DialogTitle>Delete Complaint?</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete "{deletingComplaint?.title}"?
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)} disabled={deleting}>
            Cancel
          </Button>
          <Button
            variant="contained"
            color="error"
            onClick={handleDelete}
            disabled={deleting}
            startIcon={deleting ? <CircularProgress size={16} color="inherit" /> : <DeleteOutlineIcon />}
          >
            {deleting ? 'Deleting...' : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Role Change Confirmation Dialog */}
      <Dialog open={roleDialogOpen} onClose={() => setRoleDialogOpen(false)}>
        <DialogTitle>
          {roleTargetUser?.role === 'admin' ? 'Remove Admin Access?' : 'Promote to Admin?'}
        </DialogTitle>
        <DialogContent>
          <Typography>
            {roleTargetUser?.role === 'admin'
              ? `Remove admin access from ${roleTargetUser?.full_name || roleTargetUser?.email}? They will no longer be able to manage complaints or users.`
              : `Promote ${roleTargetUser?.full_name || roleTargetUser?.email} to admin? They will be able to manage all complaints and users.`}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRoleDialogOpen(false)}>
            Cancel
          </Button>
          <Button
            variant="contained"
            color={roleTargetUser?.role === 'admin' ? 'error' : 'primary'}
            onClick={handleToggleRole}
            startIcon={roleTargetUser?.role === 'admin' ? <PersonIcon /> : <AdminPanelSettingsIcon />}
          >
            {roleTargetUser?.role === 'admin' ? 'Remove Admin' : 'Make Admin'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
