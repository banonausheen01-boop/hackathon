/*
# Fix infinite recursion in RLS policies

The admin_select_profiles and admin_select/update_complaints policies were
querying the `profiles` table FROM WITHIN a profiles policy, causing infinite
recursion. This patch:

1. Creates a SECURITY DEFINER function get_my_role() that reads the caller's
   role from profiles while bypassing RLS (runs as postgres superuser).
2. Drops the recursive admin_select_profiles policy entirely — admins see
   their own profile via the existing select_own_profile policy which is enough.
3. Replaces the admin complaints policies to use get_my_role() instead of a
   raw subselect on profiles.
*/

-- Non-recursive role helper
CREATE OR REPLACE FUNCTION public.get_my_role()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$;

-- Drop the recursive policy on profiles
DROP POLICY IF EXISTS "admin_select_profiles" ON profiles;

-- Fix admin complaints policies to use the helper function
DROP POLICY IF EXISTS "admin_select_complaints" ON complaints;
CREATE POLICY "admin_select_complaints" ON complaints FOR SELECT
  TO authenticated
  USING (public.get_my_role() = 'admin');

DROP POLICY IF EXISTS "admin_update_complaints" ON complaints;
CREATE POLICY "admin_update_complaints" ON complaints FOR UPDATE
  TO authenticated
  USING (public.get_my_role() = 'admin')
  WITH CHECK (public.get_my_role() = 'admin');
