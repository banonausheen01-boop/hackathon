"""
AI Civic Guardian - Standalone Flask Backend
A self-contained version of the app using SQLite (no Supabase required).

Run:
    pip install -r requirements.txt
    python app.py

The server starts on http://localhost:5000
"""
import os
import sqlite3
import hashlib
import secrets
import json
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, request, jsonify, send_from_directory, g
from flask_cors import CORS

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "civic_guardian.db")
STATIC_DIR = os.path.join(BASE_DIR, "static")

app = Flask(__name__, static_folder=None)
CORS(app)

CATEGORIES = [
    "Biodegradable Waste",
    "Non-Biodegradable Waste",
    "Plastic Waste",
    "Electronic Waste",
    "Garbage",
    "Pothole",
    "Broken Streetlight",
    "Water Leakage",
    "Road Damage",
]

STATUSES = ["Pending", "In Progress", "Resolved"]


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            full_name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS complaints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Pending',
            confidence_score REAL DEFAULT 0,
            image_url TEXT,
            latitude REAL,
            longitude REAL,
            location_name TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        """
    )
    conn.commit()

    # Seed an admin account if none exists
    cur = conn.execute("SELECT COUNT(*) as c FROM users WHERE role='admin'")
    if cur.fetchone()["c"] == 0:
        admin_email = os.environ.get("ADMIN_EMAIL", "admin@civicguardian.local")
        admin_pass = os.environ.get("ADMIN_PASSWORD", "admin123")
        conn.execute(
            "INSERT INTO users (email, full_name, password_hash, role, created_at) VALUES (?,?,?,?,?)",
            (
                admin_email,
                "System Admin",
                hash_password(admin_pass),
                "admin",
                now_iso(),
            ),
        )
        conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------
def now_iso():
    return datetime.now(timezone.utc).isoformat()


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 100_000)
    return f"{salt}${h.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt, hex_hash = stored.split("$")
        h = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 100_000)
        return secrets.compare_digest(h.hex(), hex_hash)
    except (ValueError, AttributeError):
        return False


def make_token(user_row) -> str:
    """Simple opaque token: base64(json). Not cryptographically secure — fine for demo."""
    import base64

    payload = {"id": user_row["id"], "email": user_row["email"], "role": user_row["role"]}
    return base64.urlsafe_b64encode(json.dumps(payload).encode()).decode()


def parse_token() -> dict | None:
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    import base64

    try:
        raw = base64.urlsafe_b64decode(auth[7:]).decode()
        return json.loads(raw)
    except Exception:
        return None


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        payload = parse_token()
        if not payload:
            return jsonify({"error": "Authentication required"}), 401
        request.current_user = payload
        return fn(*args, **kwargs)

    return wrapper


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        payload = parse_token()
        if not payload:
            return jsonify({"error": "Authentication required"}), 401
        if payload.get("role") != "admin":
            return jsonify({"error": "Admin access required"}), 403
        request.current_user = payload
        return fn(*args, **kwargs)

    return wrapper


def user_row_to_dict(row):
    return {
        "id": row["id"],
        "email": row["email"],
        "full_name": row["full_name"],
        "role": row["role"],
        "created_at": row["created_at"],
    }


def complaint_row_to_dict(row, include_user=False):
    d = {
        "id": row["id"],
        "user_id": row["user_id"],
        "title": row["title"],
        "description": row["description"],
        "category": row["category"],
        "status": row["status"],
        "confidence_score": row["confidence_score"],
        "image_url": row["image_url"],
        "latitude": row["latitude"],
        "longitude": row["longitude"],
        "location_name": row["location_name"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }
    if include_user:
        d["user"] = {
            "full_name": row["user_name"] if "user_name" in row.keys() else None,
            "email": row["user_email"] if "user_email" in row.keys() else None,
        }
    return d


# ---------------------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------------------
@app.post("/api/auth/register")
def register():
    data = request.get_json(force=True, silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    full_name = (data.get("full_name") or "").strip()
    role = (data.get("role") or "user").strip().lower()

    if not email or not password or not full_name:
        return jsonify({"error": "Email, password, and full name are required"}), 400
    if role not in ("user", "admin"):
        role = "user"

    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
    if existing:
        return jsonify({"error": "An account with that email already exists"}), 409

    cur = db.execute(
        "INSERT INTO users (email, full_name, password_hash, role, created_at) VALUES (?,?,?,?,?)",
        (email, full_name, hash_password(password), role, now_iso()),
    )
    db.commit()
    user = db.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
    return jsonify({"token": make_token(user), "user": user_row_to_dict(user)}), 201


@app.post("/api/auth/login")
def login():
    data = request.get_json(force=True, silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not user or not verify_password(password, user["password_hash"]):
        return jsonify({"error": "Invalid email or password"}), 401

    return jsonify({"token": make_token(user), "user": user_row_to_dict(user)})


@app.get("/api/auth/me")
@login_required
def me():
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (request.current_user["id"],)).fetchone()
    if not user:
        return jsonify({"error": "User not found"}), 404
    return jsonify({"user": user_row_to_dict(user)})


# ---------------------------------------------------------------------------
# Complaint routes
# ---------------------------------------------------------------------------
@app.get("/api/complaints")
@login_required
def list_complaints():
    db = get_db()
    cur = request.current_user
    only_mine = request.args.get("mine") == "true"

    if cur["role"] == "admin" and not only_mine:
        rows = db.execute(
            """
            SELECT c.*, u.full_name as user_name, u.email as user_email
            FROM complaints c JOIN users u ON c.user_id = u.id
            ORDER BY c.created_at DESC
            """
        ).fetchall()
    else:
        rows = db.execute(
            """
            SELECT c.*, u.full_name as user_name, u.email as user_email
            FROM complaints c JOIN users u ON c.user_id = u.id
            WHERE c.user_id = ?
            ORDER BY c.created_at DESC
            """,
            (cur["id"],),
        ).fetchall()

    return jsonify({"complaints": [complaint_row_to_dict(r, include_user=True) for r in rows]})


@app.post("/api/complaints")
@login_required
def create_complaint():
    data = request.get_json(force=True, silent=True) or {}
    title = (data.get("title") or "").strip()
    description = (data.get("description") or "").strip()
    category = (data.get("category") or "").strip()
    image_url = data.get("image_url")
    lat = data.get("latitude")
    lng = data.get("longitude")
    location_name = (data.get("location_name") or "").strip()

    if not title or not description or not category:
        return jsonify({"error": "Title, description, and category are required"}), 400
    if category not in CATEGORIES:
        return jsonify({"error": f"Invalid category. Valid: {CATEGORIES}"}), 400

    confidence = detect_category_confidence(description, category)

    db = get_db()
    cur = db.execute(
        """
        INSERT INTO complaints
        (user_id, title, description, category, status, confidence_score, image_url, latitude, longitude, location_name, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            request.current_user["id"],
            title,
            description,
            category,
            "Pending",
            confidence,
            image_url,
            lat,
            lng,
            location_name,
            now_iso(),
            now_iso(),
        ),
    )
    db.commit()
    row = db.execute("SELECT * FROM complaints WHERE id=?", (cur.lastrowid,)).fetchone()
    return jsonify({"complaint": complaint_row_to_dict(row)}), 201


@app.get("/api/complaints/<int:cid>")
@login_required
def get_complaint(cid):
    db = get_db()
    row = db.execute(
        """
        SELECT c.*, u.full_name as user_name, u.email as user_email
        FROM complaints c JOIN users u ON c.user_id = u.id
        WHERE c.id = ?
        """,
        (cid,),
    ).fetchone()
    if not row:
        return jsonify({"error": "Complaint not found"}), 404
    if request.current_user["role"] != "admin" and row["user_id"] != request.current_user["id"]:
        return jsonify({"error": "Not authorized to view this complaint"}), 403
    return jsonify({"complaint": complaint_row_to_dict(row, include_user=True)})


@app.patch("/api/complaints/<int:cid>/status")
@admin_required
def update_status(cid):
    data = request.get_json(force=True, silent=True) or {}
    new_status = (data.get("status") or "").strip()
    if new_status not in STATUSES:
        return jsonify({"error": f"Invalid status. Valid: {STATUSES}"}), 400

    db = get_db()
    row = db.execute("SELECT * FROM complaints WHERE id=?", (cid,)).fetchone()
    if not row:
        return jsonify({"error": "Complaint not found"}), 404
    db.execute(
        "UPDATE complaints SET status=?, updated_at=? WHERE id=?",
        (new_status, now_iso(), cid),
    )
    db.commit()
    row = db.execute("SELECT * FROM complaints WHERE id=?", (cid,)).fetchone()
    return jsonify({"complaint": complaint_row_to_dict(row)})


@app.delete("/api/complaints/<int:cid>")
@login_required
def delete_complaint(cid):
    db = get_db()
    row = db.execute("SELECT * FROM complaints WHERE id=?", (cid,)).fetchone()
    if not row:
        return jsonify({"error": "Complaint not found"}), 404
    if request.current_user["role"] != "admin" and row["user_id"] != request.current_user["id"]:
        return jsonify({"error": "Not authorized"}), 403
    db.execute("DELETE FROM complaints WHERE id=?", (cid,))
    db.commit()
    return jsonify({"ok": True})


@app.get("/api/admin/stats")
@admin_required
def admin_stats():
    db = get_db()
    total = db.execute("SELECT COUNT(*) as c FROM complaints").fetchone()["c"]
    pending = db.execute("SELECT COUNT(*) as c FROM complaints WHERE status='Pending'").fetchone()["c"]
    in_prog = db.execute("SELECT COUNT(*) as c FROM complaints WHERE status='In Progress'").fetchone()["c"]
    resolved = db.execute("SELECT COUNT(*) as c FROM complaints WHERE status='Resolved'").fetchone()["c"]
    users = db.execute("SELECT COUNT(*) as c FROM users WHERE role='user'").fetchone()["c"]

    by_cat = {
        r["category"]: r["c"]
        for r in db.execute("SELECT category, COUNT(*) as c FROM complaints GROUP BY category").fetchall()
    }
    return jsonify(
        {
            "total": total,
            "pending": pending,
            "in_progress": in_prog,
            "resolved": resolved,
            "users": users,
            "by_category": by_cat,
        }
    )


@app.get("/api/categories")
def get_categories():
    return jsonify({"categories": CATEGORIES})


# ---------------------------------------------------------------------------
# Naive "AI" category detection (keyword based)
# ---------------------------------------------------------------------------
KEYWORDS = {
    "Biodegradable Waste": ["food", "organic", "leaf", "leaves", "vegetable", "fruit", "garden"],
    "Non-Biodegradable Waste": ["waste", "trash", "rubbish", "garbage dump", "dump"],
    "Plastic Waste": ["plastic", "bottle", "bag", "wrapper", "polythene"],
    "Electronic Waste": ["electronic", "ewaste", "e-waste", "battery", "wire", "device", "circuit"],
    "Garbage": ["garbage", "litter", "dustbin", "bin overflow", "trash on road"],
    "Pothole": ["pothole", "potholes", "crater", "ditch in road"],
    "Broken Streetlight": ["streetlight", "street light", "lamp", "light not working", "broken light"],
    "Water Leakage": ["water leak", "leakage", "pipe burst", "water logging", "sewage"],
    "Road Damage": ["road damage", "broken road", "cracked road", "road crack", "damaged road"],
}


def detect_category_confidence(description: str, claimed_category: str) -> float:
    text = description.lower()
    best = 0.0
    for cat, words in KEYWORDS.items():
        score = sum(1 for w in words if w in text) / max(len(words), 1)
        if cat == claimed_category and score > best:
            best = score
    if best == 0.0:
        best = 0.5
    return round(best, 2)


# ---------------------------------------------------------------------------
# Static file serving (the frontend lives in /static)
# ---------------------------------------------------------------------------
@app.get("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


@app.get("/<path:path>")
def static_files(path):
    full = os.path.join(STATIC_DIR, path)
    if os.path.isfile(full):
        return send_from_directory(STATIC_DIR, path)
    # SPA fallback so client-side routes work on refresh
    return send_from_directory(STATIC_DIR, "index.html")


if __name__ == "__main__":
    init_db()
    print(f"AI Civic Guardian (standalone) starting on http://localhost:5000")
    print(f"Database: {DB_PATH}")
    print(f"Default admin: admin@civicguardian.local / admin123 (override with ADMIN_EMAIL / ADMIN_PASSWORD env vars)")
    app.run(host="0.0.0.0", port=5000, debug=True)
