import React, { useState, useEffect } from 'react';
import { useNavigate, Link as RouterLink, useLocation } from 'react-router-dom';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import Alert from '@mui/material/Alert';
import CircularProgress from '@mui/material/CircularProgress';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import Link from '@mui/material/Link';
import Divider from '@mui/material/Divider';
import ShieldOutlinedIcon from '@mui/icons-material/ShieldOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import AdminPanelSettingsOutlinedIcon from '@mui/icons-material/AdminPanelSettingsOutlined';
import { useAuth } from '../hooks/useAuth';

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
      <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
      <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332C2.438 15.983 5.482 18 9 18z" fill="#34A853"/>
      <path d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
      <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0 5.482 0 2.438 2.017.957 4.958L3.964 6.29C4.672 4.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
    </svg>
  );
}

export default function LoginPage() {
  const { signIn, signInWithGoogle } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loginRole, setLoginRole] = useState<'user' | 'admin'>('user');

  // Check for OAuth error params in the URL (e.g. after a failed Google redirect)
  useEffect(() => {
    const hash = new URLSearchParams(location.hash.replace('#', '?'));
    const query = new URLSearchParams(location.search);

    const errorMsg =
      hash.get('error_description') ||
      query.get('error_description') ||
      hash.get('error') ||
      query.get('error');

    if (errorMsg) {
      const decoded = decodeURIComponent(errorMsg.replace(/\+/g, ' '));
      if (decoded.toLowerCase().includes('provider') || decoded.toLowerCase().includes('not enabled')) {
        setError(
          'Google sign-in is not yet enabled. Please contact the admin or use email/password to sign in.'
        );
      } else {
        setError(decoded);
      }
      // Clean the URL
      window.history.replaceState({}, '', '/login');
    }
  }, [location]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await signIn(email, password);
    setLoading(false);
    if (error) {
      setError(error);
    } else {
      navigate(loginRole === 'admin' ? '/admin' : '/dashboard');
    }
  }

  async function handleGoogleSignIn() {
    setError(null);
    setGoogleLoading(true);
    const { error } = await signInWithGoogle(loginRole === 'admin' ? '/admin' : '/dashboard');
    setGoogleLoading(false);
    if (error) {
      if (error.toLowerCase().includes('provider') || error.toLowerCase().includes('not enabled')) {
        setError('Google sign-in is not yet configured. Please use email and password to sign in.');
      } else {
        setError(error);
      }
    }
    // On success, Supabase redirects to /dashboard automatically
  }

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'linear-gradient(135deg, #0d4035 0%, #1a6b5c 50%, #2e8b76 100%)',
        p: 2,
      }}
    >
      <Paper
        elevation={0}
        sx={{
          width: '100%',
          maxWidth: 420,
          p: { xs: 3, sm: 5 },
          borderRadius: 4,
          boxShadow: '0 24px 64px rgba(0,0,0,0.25)',
        }}
      >
        <Box sx={{ textAlign: 'center', mb: 3 }}>
          <Box
            sx={{
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 64,
              height: 64,
              borderRadius: 3,
              background: 'linear-gradient(135deg, #1a6b5c 0%, #0d4035 100%)',
              mb: 2,
            }}
          >
            <ShieldOutlinedIcon sx={{ color: 'white', fontSize: 34 }} />
          </Box>
          <Typography variant="h5" fontWeight={700} color="text.primary">
            AI Civic Guardian
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            Sign in to report and track civic issues
          </Typography>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
          Sign in as
        </Typography>
        <ToggleButtonGroup
          value={loginRole}
          exclusive
          onChange={(_, val: 'user' | 'admin' | null) => val && setLoginRole(val)}
          fullWidth
          sx={{ mb: 2 }}
        >
          <ToggleButton value="user" sx={{ py: 1 }}>
            <PersonOutlineIcon sx={{ mr: 1, fontSize: 20 }} /> User
          </ToggleButton>
          <ToggleButton value="admin" sx={{ py: 1 }}>
            <AdminPanelSettingsOutlinedIcon sx={{ mr: 1, fontSize: 20 }} /> Admin
          </ToggleButton>
        </ToggleButtonGroup>

        {/* Google Sign-In */}
        <Button
          fullWidth
          variant="outlined"
          size="large"
          onClick={handleGoogleSignIn}
          disabled={googleLoading || loading}
          startIcon={googleLoading ? <CircularProgress size={16} /> : <GoogleIcon />}
          sx={{
            mb: 2,
            py: 1.4,
            borderColor: 'divider',
            color: 'text.primary',
            fontWeight: 600,
            fontSize: '0.95rem',
            '&:hover': { borderColor: 'text.secondary', bgcolor: 'action.hover' },
          }}
        >
          {googleLoading ? 'Redirecting...' : 'Continue with Google'}
        </Button>

        <Divider sx={{ mb: 2 }}>
          <Typography variant="caption" color="text.secondary">
            or sign in with email
          </Typography>
        </Divider>

        <Box component="form" onSubmit={handleSubmit} noValidate>
          <TextField
            label="Email Address"
            type="email"
            fullWidth
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
            size="medium"
            sx={{ mb: 2 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <EmailOutlinedIcon sx={{ color: 'text.secondary', fontSize: 20 }} />
                </InputAdornment>
              ),
            }}
          />
          <TextField
            label="Password"
            type={showPassword ? 'text' : 'password'}
            fullWidth
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
            size="medium"
            sx={{ mb: 3 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <LockOutlinedIcon sx={{ color: 'text.secondary', fontSize: 20 }} />
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => setShowPassword((s) => !s)}
                    edge="end"
                    size="small"
                    aria-label="toggle password visibility"
                  >
                    {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          <Button
            type="submit"
            variant="contained"
            fullWidth
            size="large"
            disabled={loading || !email || !password}
            sx={{ py: 1.5, fontSize: '1rem' }}
          >
            {loading ? <CircularProgress size={22} color="inherit" /> : 'Sign In'}
          </Button>
        </Box>

        <Divider sx={{ my: 3 }}>
          <Typography variant="caption" color="text.secondary">
            New to Civic Guardian?
          </Typography>
        </Divider>

        <Box sx={{ textAlign: 'center' }}>
          <Link component={RouterLink} to="/register" variant="body2" fontWeight={600}>
            Create an account →
          </Link>
        </Box>
      </Paper>
    </Box>
  );
}
