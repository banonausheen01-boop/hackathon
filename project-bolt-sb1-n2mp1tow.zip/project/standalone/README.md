# AI Civic Guardian — Standalone (HTML/CSS/JS + Python Flask)

A self-contained version of the AI Civic Guardian civic-issue tracker. No Supabase, no React, no build step — just plain HTML, CSS, JavaScript, and a Python Flask backend with SQLite.

## Stack

- **Frontend**: HTML, CSS, vanilla JavaScript (single-page app)
- **Backend**: Python Flask
- **Database**: SQLite (file-based, auto-created on first run)

## Features

- Email/password registration and login
- User / Admin role toggle on the login screen
- Users can report civic issues (title, description, category, location, image URL)
- Naive keyword-based "AI" category-confidence scoring
- Admin dashboard with stats and status management (Pending → In Progress → Resolved)
- Complaint list with filtering by status and category

## Setup

```bash
cd standalone
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000 in your browser.

## Default admin account

- Email: `admin@civicguardian.local`
- Password: `admin123`

Override with environment variables before starting:

```bash
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD=secret python app.py
```

## Project structure

```
standalone/
  app.py                 # Flask backend (auth, complaints, admin, SQLite)
  requirements.txt
  README.md
  static/
    index.html           # SPA shell
    css/styles.css       # Theme (teal/green, matches the React app)
    js/app.js            # Routing, auth, CRUD, rendering
```

## API reference

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | — | Create account (`email`, `password`, `full_name`, `role`) |
| POST | `/api/auth/login` | — | Login, returns `{ token, user }` |
| GET | `/api/auth/me` | user | Current user profile |
| GET | `/api/complaints` | user | List complaints (admins see all; users see their own) |
| POST | `/api/complaints` | user | Create complaint |
| GET | `/api/complaints/:id` | user | Get one complaint |
| PATCH | `/api/complaints/:id/status` | admin | Update status |
| DELETE | `/api/complaints/:id` | user/admin | Delete (owner or admin) |
| GET | `/api/admin/stats` | admin | Aggregate dashboard stats |
| GET | `/api/categories` | — | List valid categories |

## Notes

- The auth token is a plain base64-encoded JSON payload — fine for a demo, not production. Replace with JWT or session cookies for real use.
- SQLite is single-file; delete `civic_guardian.db` to reset.
