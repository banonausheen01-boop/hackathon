import Chip from '@mui/material/Chip';
import type { ComplaintStatus, IssueCategory } from '../lib/types';

const STATUS_CONFIG: Record<ComplaintStatus, { color: 'warning' | 'info' | 'success'; label: string }> = {
  Pending: { color: 'warning', label: 'Pending' },
  'In Progress': { color: 'info', label: 'In Progress' },
  Resolved: { color: 'success', label: 'Resolved' },
};

const CATEGORY_COLORS: Record<IssueCategory, string> = {
  'Biodegradable Waste': '#558b2f',
  'Non-Biodegradable Waste': '#6d4c41',
  'Plastic Waste': '#0277bd',
  'Electronic Waste': '#4527a0',
  Garbage: '#f57f17',
  Pothole: '#bf360c',
  'Broken Streetlight': '#f9a825',
  'Water Leakage': '#0288d1',
  'Road Damage': '#546e7a',
};

export function StatusChip({ status }: { status: ComplaintStatus }) {
  const cfg = STATUS_CONFIG[status];
  return (
    <Chip
      label={cfg.label}
      color={cfg.color}
      size="small"
      variant="filled"
      sx={{ fontWeight: 700, fontSize: '0.7rem' }}
    />
  );
}

export function CategoryChip({ category }: { category: IssueCategory }) {
  return (
    <Chip
      label={category}
      size="small"
      sx={{
        fontWeight: 600,
        fontSize: '0.7rem',
        bgcolor: CATEGORY_COLORS[category] + '20',
        color: CATEGORY_COLORS[category],
        borderColor: CATEGORY_COLORS[category] + '40',
        border: '1px solid',
      }}
    />
  );
}

export { CATEGORY_COLORS };
