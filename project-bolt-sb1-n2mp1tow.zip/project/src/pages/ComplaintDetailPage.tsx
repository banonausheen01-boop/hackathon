import { useEffect, useState, Suspense, lazy } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Skeleton from '@mui/material/Skeleton';
import Alert from '@mui/material/Alert';
import Grid from '@mui/material/Grid';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Chip from '@mui/material/Chip';
import Button from '@mui/material/Button';
import LinearProgress from '@mui/material/LinearProgress';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import UpdateIcon from '@mui/icons-material/Update';
import { supabase } from '../lib/supabase';
import { StatusChip, CategoryChip } from '../components/StatusChip';
import type { Complaint } from '../lib/types';

// Lazy-load leaflet to avoid SSR issues
const MapView = lazy(() => import('../components/MapView'));

export default function ComplaintDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [complaint, setComplaint] = useState<Complaint | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    async function load() {
      const { data, error } = await supabase
        .from('complaints')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      if (error) setError(error.message);
      else if (!data) setError('Complaint not found.');
      else setComplaint(data);
      setLoading(false);
    }
    load();
  }, [id]);

  if (loading) {
    return (
      <Box sx={{ maxWidth: 800, mx: 'auto' }}>
        <Skeleton height={32} width={180} sx={{ mb: 2 }} />
        <Skeleton variant="rectangular" height={300} sx={{ borderRadius: 2, mb: 2 }} />
        <Skeleton height={24} width="60%" />
        <Skeleton height={18} />
        <Skeleton height={18} width="80%" />
      </Box>
    );
  }

  if (error || !complaint) {
    return (
      <Box sx={{ maxWidth: 800, mx: 'auto' }}>
        <Alert severity="error">{error || 'Complaint not found'}</Alert>
        <Button onClick={() => navigate('/dashboard')} sx={{ mt: 2 }}>
          Back to Dashboard
        </Button>
      </Box>
    );
  }

  const hasCoords = complaint.latitude !== null && complaint.longitude !== null;

  return (
    <Box sx={{ maxWidth: 800, mx: 'auto' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
        <IconButton onClick={() => navigate('/dashboard')} size="small">
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h5" fontWeight={700}>
          Complaint Details
        </Typography>
      </Box>

      <Grid container spacing={2}>
        {/* Image */}
        {complaint.image_url && (
          <Grid size={12}>
            <Card elevation={0}>
              <Box
                component="img"
                src={complaint.image_url}
                alt={complaint.title}
                sx={{ width: '100%', maxHeight: 350, objectFit: 'cover', borderRadius: '14px 14px 0 0' }}
              />
              <CardContent sx={{ p: 2 }}>
                <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                  <CategoryChip category={complaint.category} />
                  <StatusChip status={complaint.status} />
                  {complaint.confidence_score > 0 && (
                    <Chip
                      label={`AI: ${Math.round(complaint.confidence_score * 100)}% confidence`}
                      size="small"
                      variant="outlined"
                      color="primary"
                      sx={{ fontWeight: 600, fontSize: '0.7rem' }}
                    />
                  )}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        )}

        {/* Complaint Info */}
        <Grid size={{ xs: 12, md: hasCoords ? 7 : 12 }}>
          <Card elevation={0} sx={{ height: '100%' }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" fontWeight={700} gutterBottom>
                {complaint.title}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2, lineHeight: 1.7 }}>
                {complaint.description}
              </Typography>
              <Divider sx={{ my: 2 }} />
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                {complaint.location_name && (
                  <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                    <LocationOnOutlinedIcon sx={{ fontSize: 18, color: 'text.secondary', mt: 0.2 }} />
                    <Box>
                      <Typography variant="caption" color="text.disabled" display="block">
                        Location
                      </Typography>
                      <Typography variant="body2" fontWeight={500}>
                        {complaint.location_name}
                      </Typography>
                    </Box>
                  </Box>
                )}
                <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                  <AccessTimeIcon sx={{ fontSize: 18, color: 'text.secondary', mt: 0.2 }} />
                  <Box>
                    <Typography variant="caption" color="text.disabled" display="block">
                      Reported On
                    </Typography>
                    <Typography variant="body2" fontWeight={500}>
                      {new Date(complaint.created_at).toLocaleString()}
                    </Typography>
                  </Box>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                  <UpdateIcon sx={{ fontSize: 18, color: 'text.secondary', mt: 0.2 }} />
                  <Box>
                    <Typography variant="caption" color="text.disabled" display="block">
                      Last Updated
                    </Typography>
                    <Typography variant="body2" fontWeight={500}>
                      {new Date(complaint.updated_at).toLocaleString()}
                    </Typography>
                  </Box>
                </Box>
              </Box>
              {complaint.confidence_score > 0 && (
                <>
                  <Divider sx={{ my: 2 }} />
                  <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
                    AI Detection Confidence
                  </Typography>
                  <LinearProgress
                    variant="determinate"
                    value={complaint.confidence_score * 100}
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                  <Typography variant="caption" fontWeight={700} color="primary.main" sx={{ mt: 0.5, display: 'block' }}>
                    {Math.round(complaint.confidence_score * 100)}%
                  </Typography>
                </>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Map */}
        {hasCoords && (
          <Grid size={{ xs: 12, md: 5 }}>
            <Card elevation={0} sx={{ height: '100%', minHeight: 280 }}>
              <CardContent sx={{ p: 0, height: '100%', '&:last-child': { pb: 0 } }}>
                <Suspense fallback={<Skeleton variant="rectangular" height={280} sx={{ borderRadius: 2 }} />}>
                  <MapView
                    lat={complaint.latitude!}
                    lng={complaint.longitude!}
                    category={complaint.category}
                    title={complaint.title}
                  />
                </Suspense>
              </CardContent>
            </Card>
          </Grid>
        )}
      </Grid>
    </Box>
  );
}
