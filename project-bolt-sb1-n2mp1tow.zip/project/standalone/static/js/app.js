/**
 * AI Civic Guardian — Standalone frontend (vanilla JS SPA)
 */

const API = '/api';
const CATEGORIES = [
  'Biodegradable Waste', 'Non-Biodegradable Waste', 'Plastic Waste',
  'Electronic Waste', 'Garbage', 'Pothole', 'Broken Streetlight',
  'Water Leakage', 'Road Damage',
];
const STATUSES = ['Pending', 'In Progress', 'Resolved'];

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
const state = {
  token: localStorage.getItem('cg_token'),
  user: JSON.parse(localStorage.getItem('cg_user') || 'null'),
  loginRole: 'user',
  complaints: [],
  filters: { status: '', category: '', search: '' },
};

// ---------------------------------------------------------------------------
// API helpers
// ---------------------------------------------------------------------------
async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  try {
    const res = await fetch(API + path, { ...opts, headers });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  } catch (e) {
    if (e.message === 'Authentication required' || e.message === 'Admin access required') {
      logout();
    }
    throw e;
  }
}

function setAuth(token, user) {
  state.token = token;
  state.user = user;
  localStorage.setItem('cg_token', token);
  localStorage.setItem('cg_user', JSON.stringify(user));
}

function logout() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('cg_token');
  localStorage.removeItem('cg_user');
  navigate('/login');
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
function navigate(path) {
  history.pushState({}, '', path);
  render();
}

window.addEventListener('popstate', render);

function render() {
  const path = location.pathname;
  const app = document.getElementById('app');

  if (!state.token) {
    if (path === '/register') return renderRegister();
    return renderLogin();
  }

  if (path === '/login' || path === '/register') {
    navigate('/dashboard');
    return;
  }

  // Authenticated routes — wrap in layout
  let page;
  switch (true) {
    case path === '/dashboard': page = renderDashboard(); break;
    case path === '/complaints/new': page = renderNewComplaint(); break;
    case /^\/complaints\/\d+$/.test(path): page = renderComplaintDetail(path); break;
    case path === '/admin': page = state.user.role === 'admin' ? renderAdmin() : renderDashboard(); break;
    default: page = renderDashboard();
  }
  app.innerHTML = layoutShell() + page + '</main></div>';
  bindSidebar();
  setTimeout(postRender, 0);
}

function layoutShell() {
  const u = state.user || {};
  const isAdmin = u.role === 'admin';
  const initial = (u.full_name || 'U')[0].toUpperCase();
  return `
    <div class="layout">
      <div class="mobile-bar">
        <button onclick="toggleSidebar()">${iconMenu()}</button>
        <h2>AI Civic Guardian</h2>
      </div>
      <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
          ${iconShield()}
          <div><h2>AI Civic Guardian</h2><p>Civic Issue Tracker</p></div>
        </div>
        <div class="sidebar-profile">
          <div class="avatar">${initial}</div>
          <div class="profile-info">
            <div class="name">${esc(u.full_name || 'User')}</div>
            <div class="email">${esc(u.email || '')}</div>
          </div>
          ${isAdmin ? '<span class="chip chip-admin">Admin</span>' : ''}
        </div>
        <ul class="nav-list">
          ${navItem('Dashboard', '/dashboard', iconDashboard())}
          ${navItem('Report Issue', '/complaints/new', iconAdd())}
          ${isAdmin ? navItem('Admin Panel', '/admin', iconAdmin()) : ''}
        </ul>
        <div class="sidebar-footer">
          <button class="signout-btn" onclick="logout()">${iconLogout()} Sign Out</button>
        </div>
      </aside>
      <main class="main-content" id="main">
  `;
}

function navItem(label, path, iconHtml) {
  const active = location.pathname === path ? 'active' : '';
  return `<li><a href="${path}" class="${active}" onclick="event.preventDefault();navigate('${path}')" data-path="${path}">${iconHtml} ${label}</a></li>`;
}

function bindSidebar() {
  // close sidebar on nav click (mobile)
  document.querySelectorAll('.nav-list a').forEach((a) => {
    a.addEventListener('click', () => {
      const sb = document.getElementById('sidebar');
      if (sb) sb.classList.remove('open');
    });
  });
}

window.toggleSidebar = () => {
  document.getElementById('sidebar').classList.toggle('open');
};

// ---------------------------------------------------------------------------
// Login page
// ---------------------------------------------------------------------------
function renderLogin() {
  document.getElementById('app').innerHTML = `
    <div class="auth-wrap">
      <div class="auth-card">
        <div class="auth-logo">${iconShield()}</div>
        <h1 class="auth-title">AI Civic Guardian</h1>
        <p class="auth-subtitle">Sign in to report and track civic issues</p>
        <div id="login-alert"></div>
        <label class="role-label">Sign in as</label>
        <div class="role-toggle" id="role-toggle">
          <button class="${state.loginRole === 'user' ? 'active' : ''}" data-role="user">${iconPerson()} User</button>
          <button class="${state.loginRole === 'admin' ? 'active' : ''}" data-role="admin">${iconAdmin()} Admin</button>
        </div>
        <form id="login-form">
          <div class="form-group">
            <label>Email Address</label>
            <input type="email" id="email" required autocomplete="email" />
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" id="password" required autocomplete="current-password" />
          </div>
          <button type="submit" class="btn-primary" id="login-btn">Sign In</button>
        </form>
        <div class="auth-divider">New to Civic Guardian?</div>
        <div class="auth-link"><a href="/register" onclick="event.preventDefault();navigate('/register')">Create an account →</a></div>
      </div>
    </div>
  `;
  document.querySelectorAll('#role-toggle button').forEach((b) => {
    b.onclick = () => {
      state.loginRole = b.dataset.role;
      document.querySelectorAll('#role-toggle button').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
    };
  });
  document.getElementById('login-form').onsubmit = handleLogin;
}

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const btn = document.getElementById('login-btn');
  btn.disabled = true; btn.textContent = 'Signing in...';
  clearAlert('login-alert');
  try {
    const data = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setAuth(data.token, data.user);
    if (state.loginRole === 'admin' && data.user.role !== 'admin') {
      showAlert('login-alert', 'This account is not an admin. Logging in as user.', 'error');
      navigate('/dashboard');
    } else {
      navigate(state.loginRole === 'admin' ? '/admin' : '/dashboard');
    }
  } catch (err) {
    showAlert('login-alert', err.message, 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'Sign In';
  }
}

// ---------------------------------------------------------------------------
// Register page
// ---------------------------------------------------------------------------
function renderRegister() {
  document.getElementById('app').innerHTML = `
    <div class="auth-wrap">
      <div class="auth-card">
        <div class="auth-logo">${iconShield()}</div>
        <h1 class="auth-title">Create Account</h1>
        <p class="auth-subtitle">Join Civic Guardian to report issues</p>
        <div id="reg-alert"></div>
        <form id="reg-form">
          <div class="form-group">
            <label>Full Name</label>
            <input type="text" id="full_name" required />
          </div>
          <div class="form-group">
            <label>Email Address</label>
            <input type="email" id="email" required autocomplete="email" />
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" id="password" required autocomplete="new-password" minlength="6" />
          </div>
          <div class="form-group">
            <label>Account Type</label>
            <select id="role">
              <option value="user">User — report and track issues</option>
              <option value="admin">Admin — manage all complaints</option>
            </select>
          </div>
          <button type="submit" class="btn-primary" id="reg-btn">Create Account</button>
        </form>
        <div class="auth-divider">Already have an account?</div>
        <div class="auth-link"><a href="/login" onclick="event.preventDefault();navigate('/login')">← Back to sign in</a></div>
      </div>
    </div>
  `;
  document.getElementById('reg-form').onsubmit = handleRegister;
}

async function handleRegister(e) {
  e.preventDefault();
  const full_name = document.getElementById('full_name').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const role = document.getElementById('role').value;
  const btn = document.getElementById('reg-btn');
  btn.disabled = true; btn.textContent = 'Creating...';
  clearAlert('reg-alert');
  try {
    const data = await api('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ full_name, email, password, role }),
    });
    setAuth(data.token, data.user);
    navigate(role === 'admin' ? '/admin' : '/dashboard');
  } catch (err) {
    showAlert('reg-alert', err.message, 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'Create Account';
  }
}

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------
function renderDashboard() {
  return `
    <div class="page-header">
      <div>
        <h1>Dashboard</h1>
        <p>Welcome back, ${esc(state.user?.full_name || 'User')}</p>
      </div>
      <button class="btn-primary" style="width:auto;padding:10px 22px" onclick="navigate('/complaints/new')">+ Report New Issue</button>
    </div>
    <div class="filters">
      <input type="text" placeholder="Search title or description..." id="f-search" value="${esc(state.filters.search)}" oninput="state.filters.search=this.value;refreshList()" />
      <select id="f-status" onchange="state.filters.status=this.value;refreshList()">
        <option value="">All Statuses</option>
        ${STATUSES.map((s) => `<option ${state.filters.status === s ? 'selected' : ''}>${s}</option>`).join('')}
      </select>
      <select id="f-category" onchange="state.filters.category=this.value;refreshList()">
        <option value="">All Categories</option>
        ${CATEGORIES.map((c) => `<option ${state.filters.category === c ? 'selected' : ''}>${c}</option>`).join('')}
      </select>
    </div>
    <div id="complaints-list"><div class="spinner"><div class="spinner-circle"></div></div></div>
  `;
}

async function refreshList() {
  try {
    const data = await api('/complaints');
    state.complaints = data.complaints || [];
    renderComplaintList();
  } catch (err) {
    document.getElementById('complaints-list').innerHTML = `<div class="alert alert-error">${esc(err.message)}</div>`;
  }
}

function renderComplaintList() {
  let list = state.complaints;
  const { status, category, search } = state.filters;
  if (status) list = list.filter((c) => c.status === status);
  if (category) list = list.filter((c) => c.category === category);
  if (search) {
    const q = search.toLowerCase();
    list = list.filter((c) => c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q));
  }

  const el = document.getElementById('complaints-list');
  if (!el) return;
  if (list.length === 0) {
    el.innerHTML = `
      <div class="empty-state">${iconReport()}<h3>No complaints found</h3><p>Try adjusting filters or report a new issue.</p></div>
    `;
    return;
  }
  el.innerHTML = list.map(complaintCardHtml).join('');
  el.querySelectorAll('.complaint-card').forEach((c) => {
    c.onclick = () => navigate('/complaints/' + c.dataset.id);
  });
}

function complaintCardHtml(c) {
  const cls = c.status.toLowerCase().replace(/\s/g, '-');
  return `
    <div class="complaint-card ${cls}" data-id="${c.id}">
      <div class="top">
        <div>
          <h3>${esc(c.title)}</h3>
          <div class="meta">${esc(c.category)} · ${formatDate(c.created_at)} ${c.user?.full_name ? '· by ' + esc(c.user.full_name) : ''}</div>
        </div>
        <span class="status-badge ${cls}">${c.status}</span>
      </div>
      <p class="desc">${esc(c.description).slice(0, 180)}${c.description.length > 180 ? '...' : ''}</p>
      ${c.location_name ? `<div class="meta">📍 ${esc(c.location_name)}</div>` : ''}
    </div>
  `;
}

// ---------------------------------------------------------------------------
// New complaint
// ---------------------------------------------------------------------------
function renderNewComplaint() {
  return `
    <div class="page-header">
      <div><h1>Report an Issue</h1><p>Describe the civic problem you encountered</p></div>
    </div>
    <div id="nc-alert"></div>
    <form id="nc-form" style="max-width:600px">
      <div class="form-group">
        <label>Title</label>
        <input type="text" id="nc-title" required placeholder="e.g. Large pothole near MG Road" />
      </div>
      <div class="form-group">
        <label>Description</label>
        <textarea id="nc-desc" required placeholder="Describe the issue in detail..."></textarea>
      </div>
      <div class="form-group">
        <label>Category</label>
        <select id="nc-category">
          ${CATEGORIES.map((c) => `<option>${c}</option>`).join('')}
        </select>
      </div>
      <div class="two-col">
        <div class="form-group">
          <label>Location Name (optional)</label>
          <input type="text" id="nc-location" placeholder="e.g. MG Road, Bengaluru" />
        </div>
        <div class="form-group">
          <label>Image URL (optional)</label>
          <input type="url" id="nc-image" placeholder="https://..." />
        </div>
      </div>
      <div class="two-col">
        <div class="form-group">
          <label>Latitude (optional)</label>
          <input type="number" step="any" id="nc-lat" placeholder="12.9716" />
        </div>
        <div class="form-group">
          <label>Longitude (optional)</label>
          <input type="number" step="any" id="nc-lng" placeholder="77.5946" />
        </div>
      </div>
      <button type="submit" class="btn-primary" id="nc-btn" style="max-width:200px">Submit Report</button>
    </form>
  `;
}

async function handleNewComplaint(e) {
  e.preventDefault();
  const body = {
    title: document.getElementById('nc-title').value.trim(),
    description: document.getElementById('nc-desc').value.trim(),
    category: document.getElementById('nc-category').value,
    location_name: document.getElementById('nc-location').value.trim(),
    image_url: document.getElementById('nc-image').value.trim() || null,
    latitude: parseFloat(document.getElementById('nc-lat').value) || null,
    longitude: parseFloat(document.getElementById('nc-lng').value) || null,
  };
  const btn = document.getElementById('nc-btn');
  btn.disabled = true; btn.textContent = 'Submitting...';
  clearAlert('nc-alert');
  try {
    const data = await api('/complaints', { method: 'POST', body: JSON.stringify(body) });
    navigate('/complaints/' + data.complaint.id);
  } catch (err) {
    showAlert('nc-alert', err.message, 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'Submit Report';
  }
}

// ---------------------------------------------------------------------------
// Complaint detail
// ---------------------------------------------------------------------------
function renderComplaintDetail(path) {
  const id = path.split('/').pop();
  return `
    <div id="detail-view"><div class="spinner"><div class="spinner-circle"></div></div></div>
  `;
}

async function loadComplaintDetail(id) {
  const el = document.getElementById('detail-view');
  try {
    const data = await api('/complaints/' + id);
    const c = data.complaint;
    const cls = c.status.toLowerCase().replace(/\s/g, '-');
    const canManage = state.user.role === 'admin' || c.user_id === state.user.id;
    el.innerHTML = `
      <a class="back-link" href="/dashboard" onclick="event.preventDefault();navigate('/dashboard')">← Back to Dashboard</a>
      <div class="card">
        <div class="top" style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
          <div>
            <h1 style="font-size:1.3rem">${esc(c.title)}</h1>
            <div class="meta" style="color:var(--text-secondary);font-size:0.8rem;margin-top:4px">
              ${formatDate(c.created_at)} ${c.user?.full_name ? '· by ' + esc(c.user.full_name) : ''}
            </div>
          </div>
          <span class="status-badge ${cls}">${c.status}</span>
        </div>
        <div style="margin:12px 0">
          <span class="category-badge">${esc(c.category)}</span>
          <span class="confidence">AI confidence: ${(c.confidence_score * 100).toFixed(0)}%</span>
        </div>
        <div class="detail-section">
          <div class="detail-label">Description</div>
          <div class="detail-value">${esc(c.description)}</div>
        </div>
        ${c.location_name ? `<div class="detail-section"><div class="detail-label">Location</div><div class="detail-value">📍 ${esc(c.location_name)}</div></div>` : ''}
        ${c.latitude ? `<div class="detail-section"><div class="detail-label">Coordinates</div><div class="detail-value">${c.latitude}, ${c.longitude}</div></div>` : ''}
        ${c.image_url ? `<div class="detail-section"><div class="detail-label">Image</div><img src="${esc(c.image_url)}" alt="complaint" style="max-width:100%;border-radius:8px;margin-top:8px" /></div>` : ''}
        ${state.user.role === 'admin' ? `
          <div class="detail-section">
            <div class="detail-label">Update Status</div>
            <select class="status-select" onchange="updateStatus(${c.id}, this.value)">
              ${STATUSES.map((s) => `<option ${c.status === s ? 'selected' : ''}>${s}</option>`).join('')}
            </select>
          </div>
        ` : ''}
        ${canManage ? `<button class="btn-secondary" style="color:var(--error);margin-top:16px" onclick="deleteComplaint(${c.id})">Delete Complaint</button>` : ''}
      </div>
    `;
  } catch (err) {
    el.innerHTML = `<div class="alert alert-error">${esc(err.message)}</div>`;
  }
}

window.updateStatus = async (id, status) => {
  try {
    await api(`/complaints/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
    loadComplaintDetail(id);
  } catch (err) {
    alert(err.message);
  }
};

window.deleteComplaint = async (id) => {
  if (!confirm('Delete this complaint? This cannot be undone.')) return;
  try {
    await api(`/complaints/${id}`, { method: 'DELETE' });
    navigate('/dashboard');
  } catch (err) {
    alert(err.message);
  }
};

// ---------------------------------------------------------------------------
// Admin dashboard
// ---------------------------------------------------------------------------
function renderAdmin() {
  return `
    <div class="page-header"><div><h1>Admin Panel</h1><p>Manage all civic complaints</p></div></div>
    <div id="admin-stats" class="stats-grid"><div class="spinner"><div class="spinner-circle"></div></div></div>
    <div class="filters">
      <input type="text" placeholder="Search..." id="a-search" oninput="state.filters.search=this.value;renderAdminTable()" />
      <select id="a-status" onchange="state.filters.status=this.value;renderAdminTable()">
        <option value="">All Statuses</option>
        ${STATUSES.map((s) => `<option ${state.filters.status === s ? 'selected' : ''}>${s}</option>`).join('')}
      </select>
    </div>
    <div class="card"><div id="admin-table"><div class="spinner"><div class="spinner-circle"></div></div></div></div>
  `;
}

async function loadAdmin() {
  try {
    const [stats, list] = await Promise.all([api('/admin/stats'), api('/complaints')]);
    state.complaints = list.complaints || [];
    const s = stats;
    document.getElementById('admin-stats').innerHTML = `
      ${statCard('Total Complaints', s.total, iconReport())}
      ${statCard('Pending', s.pending, iconPending())}
      ${statCard('In Progress', s.in_progress, iconProgress())}
      ${statCard('Resolved', s.resolved, iconCheck())}
      ${statCard('Users', s.users, iconPerson())}
    `;
    renderAdminTable();
  } catch (err) {
    document.getElementById('admin-stats').innerHTML = `<div class="alert alert-error">${esc(err.message)}</div>`;
  }
}

function statCard(label, value, iconHtml) {
  return `<div class="stat-card"><div class="icon">${iconHtml}</div><div class="label">${label}</div><div class="value">${value}</div></div>`;
}

function renderAdminTable() {
  let list = state.complaints;
  const { status, search } = state.filters;
  if (status) list = list.filter((c) => c.status === status);
  if (search) {
    const q = search.toLowerCase();
    list = list.filter((c) => c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q));
  }
  const el = document.getElementById('admin-table');
  if (!el) return;
  if (list.length === 0) {
    el.innerHTML = `<div class="empty-state"><h3>No complaints</h3></div>`;
    return;
  }
  el.innerHTML = `
    <div class="table-wrap"><table>
      <thead><tr><th>ID</th><th>Title</th><th>Category</th><th>Status</th><th>Reported By</th><th>Date</th></tr></thead>
      <tbody>
        ${list.map((c) => `
          <tr style="cursor:pointer" onclick="navigate('/complaints/${c.id}')">
            <td>#${c.id}</td>
            <td>${esc(c.title)}</td>
            <td>${esc(c.category)}</td>
            <td><span class="status-badge ${c.status.toLowerCase().replace(/\s/g, '-')}">${c.status}</span></td>
            <td>${esc(c.user?.full_name || '-')}</td>
            <td>${formatDate(c.created_at)}</td>
          </tr>
        `).join('')}
      </tbody>
    </table></div>
  `;
}

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------
function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}

function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

function showAlert(id, msg, type = 'error') {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = `<div class="alert alert-${type}">${esc(msg)}<button class="alert-close" onclick="this.parentElement.remove()">×</button></div>`;
}

function clearAlert(id) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = '';
}

// ---------------------------------------------------------------------------
// Inline SVG icons (Material-ish, monochrome)
// ---------------------------------------------------------------------------
const IS = (p) => `<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="vertical-align:middle">${p}</svg>`;
function iconShield() { return IS('<path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>'); }
function iconDashboard() { return IS('<path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/>'); }
function iconAdd() { return IS('<path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>'); }
function iconAdmin() { return IS('<path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/>'); }
function iconLogout() { return IS('<path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/>'); }
function iconMenu() { return IS('<path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>'); }
function iconPerson() { return IS('<path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>'); }
function iconReport() { return IS('<path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>'); }
function iconPending() { return IS('<path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>'); }
function iconProgress() { return IS('<path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"/><path d="M12.5 7H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>'); }
function iconCheck() { return IS('<path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>'); }

// ---------------------------------------------------------------------------
// Init + post-render hooks
// ---------------------------------------------------------------------------
function postRender() {
  const path = location.pathname;
  if (path === '/dashboard') refreshList();
  if (path === '/complaints/new') {
    const f = document.getElementById('nc-form');
    if (f) f.onsubmit = handleNewComplaint;
  }
  if (/^\/complaints\/\d+$/.test(path)) loadComplaintDetail(path.split('/').pop());
  if (path === '/admin') loadAdmin();
}

document.addEventListener('DOMContentLoaded', render);
