import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActionArea from '@mui/material/CardActionArea';
import Grid from '@mui/material/Grid';
import Chip from '@mui/material/Chip';
import Skeleton from '@mui/material/Skeleton';
import Alert from '@mui/material/Alert';
import LinearProgress from '@mui/material/LinearProgress';
import Divider from '@mui/material/Divider';
import Avatar from '@mui/material/Avatar';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import HourglassEmptyIcon from '@mui/icons-material/HourglassEmpty';
import SyncIcon from '@mui/icons-material/Sync';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { StatusChip, CategoryChip } from '../components/StatusChip';
import type { Complaint } from '../lib/types';

interface Stats {
  total: number;
  pending: number;
  inProgress: number;
  resolved: number;
}

export default function DashboardPage() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const stats: Stats = {
    total: complaints.length,
    pending: complaints.filter((c) => c.status === 'Pending').length,
    inProgress: complaints.filter((c) => c.status === 'In Progress').length,
    resolved: complaints.filter((c) => c.status === 'Resolved').length,
  };

  useEffect(() => {
    if (!user) return;
    async function load() {
      setLoading(true);
      const { data, error } = await supabase
        .from('complaints')
        .select('*')
        .eq('user_id', user!.id)
        .order('created_at', { ascending: false });
      if (error) {
        setError(error.message);
      } else {
        setComplaints(data ?? []);
      }
      setLoading(false);
    }
    load();
  }, [user]);

  const STAT_CARDS = [
    {
      label: 'Total Reports',
      value: stats.total,
      icon: <AssignmentOutlinedIcon />,
      color: '#1a6b5c',
      bg: '#1a6b5c15',
    },
    {
      label: 'Pending',
      value: stats.pending,
      icon: <HourglassEmptyIcon />,
      color: '#e65100',
      bg: '#e6510015',
    },
    {
      label: 'In Progress',
      value: stats.inProgress,
      icon: <SyncIcon />,
      color: '#0288d1',
      bg: '#0288d115',
    },
    {
      label: 'Resolved',
      value: stats.resolved,
      icon: <CheckCircleOutlineIcon />,
      color: '#2e7d32',
      bg: '#2e7d3215',
    },
  ];

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', mb: 3, flexWrap: 'wrap', gap: 2 }}>
        <Box>
          <Typography variant="h5" fontWeight={700} color="text.primary">
            Welcome back, {profile?.full_name?.split(' ')[0] || 'Citizen'} 👋
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            Track and manage your civic issue reports
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<AddCircleOutlineIcon />}
          onClick={() => navigate('/complaints/new')}
          size="large"
        >
          Report Issue
        </Button>
      </Box>

      {/* Stats */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {STAT_CARDS.map((s) => (
          <Grid size={{ xs: 6, sm: 3 }} key={s.label}>
            <Card elevation={0}>
              <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                  <Avatar sx={{ bgcolor: s.bg, color: s.color, width: 44, height: 44 }}>
                    {s.icon}
                  </Avatar>
                  <Box>
                    <Typography variant="h5" fontWeight={700} color={s.color}>
                      {loading ? <Skeleton width={30} /> : s.value}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" fontWeight={500}>
                      {s.label}
                    </Typography>
                  </Box>
                </Box>
                {stats.total > 0 && !loading && (
                  <LinearProgress
                    variant="determinate"
                    value={stats.total > 0 ? (s.value / stats.total) * 100 : 0}
                    sx={{ mt: 1.5, bgcolor: s.bg, '& .MuiLinearProgress-bar': { bgcolor: s.color } }}
                  />
                )}
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Complaints List */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6" fontWeight={600}>
          My Reports
        </Typography>
        <Chip label={stats.total} size="small" sx={{ ml: 1, fontWeight: 700 }} />
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {loading ? (
        <Grid container spacing={2}>
          {Array.from({ length: 4 }).map((_, i) => (
            <Grid size={{ xs: 12, sm: 6, lg: 4 }} key={i}>
              <Card elevation={0}>
                <CardContent>
                  <Skeleton variant="rectangular" height={140} sx={{ borderRadius: 2, mb: 1.5 }} />
                  <Skeleton height={24} width="80%" />
                  <Skeleton height={18} width="60%" />
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      ) : complaints.length === 0 ? (
        <Card elevation={0} sx={{ textAlign: 'center', py: 6 }}>
          <AssignmentOutlinedIcon sx={{ fontSize: 56, color: 'text.disabled', mb: 1 }} />
          <Typography variant="h6" color="text.secondary" fontWeight={600}>
            No reports yet
          </Typography>
          <Typography variant="body2" color="text.disabled" sx={{ mb: 3 }}>
            Upload a photo of a civic issue to get started
          </Typography>
          <Button variant="contained" startIcon={<AddCircleOutlineIcon />} onClick={() => navigate('/complaints/new')}>
            Report Your First Issue
          </Button>
        </Card>
      ) : (
        <Grid container spacing={2}>
          {complaints.map((complaint) => (
            <Grid size={{ xs: 12, sm: 6, lg: 4 }} key={complaint.id}>
              <ComplaintCard complaint={complaint} onClick={() => navigate(`/complaints/${complaint.id}`)} />
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  );
}

function ComplaintCard({ complaint, onClick }: { complaint: Complaint; onClick: () => void }) {
  return (
    <Card elevation={0} sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <CardActionArea onClick={onClick} sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', alignItems: 'stretch' }}>
        {complaint.image_url && (
          <Box
            component="img"
            src={complaint.image_url}
            alt={complaint.title}
            sx={{ width: '100%', height: 150, objectFit: 'cover', borderRadius: '14px 14px 0 0' }}
          />
        )}
        {!complaint.image_url && (
          <Box
            sx={{
              height: 150,
              bgcolor: 'background.default',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: '14px 14px 0 0',
            }}
          >
            <AssignmentOutlinedIcon sx={{ fontSize: 40, color: 'text.disabled' }} />
          </Box>
        )}
        <CardContent sx={{ flexGrow: 1, p: 2, '&:last-child': { pb: 2 } }}>
          <Box sx={{ display: 'flex', gap: 1, mb: 1, flexWrap: 'wrap' }}>
            <CategoryChip category={complaint.category} />
            <StatusChip status={complaint.status} />
          </Box>
          <Typography variant="subtitle2" fontWeight={700} gutterBottom sx={{ lineHeight: 1.4 }}>
            {complaint.title}
          </Typography>
          <Typography
            variant="caption"
            color="text.secondary"
            sx={{ display: '-webkit-box', mb: 1, overflow: 'hidden', textOverflow: 'ellipsis', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}
          >
            {complaint.description}
          </Typography>
          <Divider sx={{ my: 1 }} />
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
            {complaint.location_name && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <LocationOnOutlinedIcon sx={{ fontSize: 13, color: 'text.disabled' }} />
                <Typography variant="caption" color="text.disabled" noWrap>
                  {complaint.location_name}
                </Typography>
              </Box>
            )}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, ml: 'auto' }}>
              <AccessTimeIcon sx={{ fontSize: 13, color: 'text.disabled' }} />
              <Typography variant="caption" color="text.disabled">
                {new Date(complaint.created_at).toLocaleDateString()}
              </Typography>
            </Box>
          </Box>
          {complaint.confidence_score > 0 && (
            <Box sx={{ mt: 1 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                <Typography variant="caption" color="text.secondary">
                  AI Confidence
                </Typography>
                <Typography variant="caption" fontWeight={700} color="primary.main">
                  {Math.round(complaint.confidence_score * 100)}%
                </Typography>
              </Box>
              <LinearProgress
                variant="determinate"
                value={complaint.confidence_score * 100}
                sx={{ height: 4, borderRadius: 2 }}
              />
            </Box>
          )}
        </CardContent>
      </CardActionArea>
    </Card>
  );
}
