/*
# Supabase Storage Bucket for Complaint Images

Creates a public storage bucket for complaint images so the frontend can
upload images and display them without authentication.

1. Bucket: 'complaint-images' — public read, authenticated write
2. Storage policies:
   - Any authenticated user can upload to the bucket
   - Anyone (anon) can read/view images (public URLs)
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('complaint-images', 'complaint-images', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "auth_upload_complaint_images" ON storage.objects;
CREATE POLICY "auth_upload_complaint_images" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'complaint-images');

DROP POLICY IF EXISTS "public_read_complaint_images" ON storage.objects;
CREATE POLICY "public_read_complaint_images" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'complaint-images');

DROP POLICY IF EXISTS "auth_update_complaint_images" ON storage.objects;
CREATE POLICY "auth_update_complaint_images" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'complaint-images');

DROP POLICY IF EXISTS "auth_delete_complaint_images" ON storage.objects;
CREATE POLICY "auth_delete_complaint_images" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'complaint-images');
