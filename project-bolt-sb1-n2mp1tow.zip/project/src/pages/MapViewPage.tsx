import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Skeleton from '@mui/material/Skeleton';
import Alert from '@mui/material/Alert';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { StatusChip, CategoryChip, CATEGORY_COLORS } from '../components/StatusChip';
import type { Complaint, IssueCategory } from '../lib/types';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

function createIcon(color: string) {
  return L.divIcon({
    html: `<div style="width:20px;height:20px;background:${color};border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:3px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3)"></div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 20],
    className: '',
  });
}

export default function MapViewPage() {
  const { user, isAdmin } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      let query = supabase
        .from('complaints')
        .select('*')
        .not('latitude', 'is', null)
        .not('longitude', 'is', null);

      if (!isAdmin) query = query.eq('user_id', user!.id);

      const { data, error } = await query.order('created_at', { ascending: false });
      if (error) setError(error.message);
      else setComplaints(data ?? []);
      setLoading(false);
    }
    load();
  }, [user, isAdmin]);

  const mappedComplaints = complaints.filter(
    (c) => c.latitude !== null && c.longitude !== null
  );

  return (
    <Box>
      <Box sx={{ mb: 2 }}>
        <Typography variant="h5" fontWeight={700}>
          Issue Map
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Geographic view of reported civic issues
        </Typography>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Card elevation={0}>
        <CardContent sx={{ p: 0, '&:last-child': { pb: 0 } }}>
          {loading ? (
            <Skeleton variant="rectangular" height={500} />
          ) : (
            <Box sx={{ height: 500, borderRadius: 2, overflow: 'hidden' }}>
              <MapContainer
                center={
                  mappedComplaints.length > 0
                    ? [mappedComplaints[0].latitude!, mappedComplaints[0].longitude!]
                    : [20.5937, 78.9629]
                }
                zoom={mappedComplaints.length > 0 ? 13 : 5}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                {mappedComplaints.map((c) => (
                  <Marker
                    key={c.id}
                    position={[c.latitude!, c.longitude!]}
                    icon={createIcon(CATEGORY_COLORS[c.category])}
                  >
                    <Popup>
                      <Box sx={{ minWidth: 160 }}>
                        <Typography variant="body2" fontWeight={700} sx={{ mb: 0.5 }}>
                          {c.title}
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mb: 0.5 }}>
                          <CategoryChip category={c.category} />
                          <StatusChip status={c.status} />
                        </Box>
                        {c.location_name && (
                          <Typography variant="caption" color="text.secondary">
                            {c.location_name}
                          </Typography>
                        )}
                      </Box>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Legend */}
      <Card elevation={0} sx={{ mt: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ mb: 1, display: 'block' }}>
            LEGEND
          </Typography>
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap' }}>
            {(Object.entries(CATEGORY_COLORS) as [IssueCategory, string][]).map(([cat, color]) => (
              <Box key={cat} sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                <Box
                  sx={{
                    width: 12,
                    height: 12,
                    borderRadius: '50%',
                    bgcolor: color,
                    border: '2px solid white',
                    boxShadow: `0 0 0 1px ${color}`,
                  }}
                />
                <Typography variant="caption">{cat}</Typography>
              </Box>
            ))}
          </Box>
        </CardContent>
      </Card>

      {mappedComplaints.length === 0 && !loading && (
        <Alert severity="info" sx={{ mt: 2 }}>
          No complaints with location data yet. Add GPS coordinates when reporting issues to see them here.
        </Alert>
      )}
    </Box>
  );
}
