import { createTheme, responsiveFontSizes } from '@mui/material/styles';
import { green, orange, red, blue } from '@mui/material/colors';

let theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1a6b5c',
      light: '#4d9a87',
      dark: '#0d4035',
      contrastText: '#ffffff',
    },
    secondary: {
      main: '#e65100',
      light: '#ff8330',
      dark: '#ac1900',
      contrastText: '#ffffff',
    },
    success: {
      main: green[600],
      light: green[400],
      dark: green[800],
    },
    warning: {
      main: orange[700],
      light: orange[400],
      dark: orange[900],
    },
    error: {
      main: red[600],
      light: red[400],
      dark: red[800],
    },
    info: {
      main: blue[700],
      light: blue[400],
      dark: blue[900],
    },
    background: {
      default: '#f4f6f4',
      paper: '#ffffff',
    },
    text: {
      primary: '#1a2e28',
      secondary: '#4a6560',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h1: { fontWeight: 700, letterSpacing: '-0.02em' },
    h2: { fontWeight: 700, letterSpacing: '-0.01em' },
    h3: { fontWeight: 600 },
    h4: { fontWeight: 600 },
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 },
    subtitle1: { fontWeight: 500 },
    button: { fontWeight: 600, textTransform: 'none' },
  },
  shape: {
    borderRadius: 10,
  },
  components: {
    MuiButton: {
      defaultProps: { disableElevation: true },
      styleOverrides: {
        root: { borderRadius: 8, paddingLeft: 20, paddingRight: 20 },
        containedPrimary: {
          background: 'linear-gradient(135deg, #1a6b5c 0%, #0d4035 100%)',
          '&:hover': { background: 'linear-gradient(135deg, #226e60 0%, #155045 100%)' },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 14,
          boxShadow: '0 2px 12px rgba(26,107,92,0.08)',
          border: '1px solid rgba(26,107,92,0.08)',
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 600, borderRadius: 8 },
      },
    },
    MuiTextField: {
      defaultProps: { variant: 'outlined', size: 'small' },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'linear-gradient(135deg, #1a6b5c 0%, #0d4035 100%)',
          boxShadow: '0 2px 12px rgba(13,64,53,0.25)',
        },
      },
    },
    MuiTableHead: {
      styleOverrides: {
        root: {
          '& .MuiTableCell-head': {
            backgroundColor: '#f4f6f4',
            fontWeight: 700,
            color: '#1a2e28',
          },
        },
      },
    },
    MuiLinearProgress: {
      styleOverrides: {
        root: { borderRadius: 4, height: 8 },
      },
    },
    MuiAlert: {
      styleOverrides: {
        root: { borderRadius: 10 },
      },
    },
  },
});

theme = responsiveFontSizes(theme);

export default theme;
