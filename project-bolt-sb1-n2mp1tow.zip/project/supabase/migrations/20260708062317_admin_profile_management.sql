-- Allow admins to read all profiles (for user management panel)
DROP POLICY IF EXISTS "admin_select_all_profiles" ON profiles;
CREATE POLICY "admin_select_all_profiles" ON profiles FOR SELECT
  TO authenticated
  USING (public.get_my_role() = 'admin');

-- Allow admins to update any profile's role
DROP POLICY IF EXISTS "admin_update_profiles" ON profiles;
CREATE POLICY "admin_update_profiles" ON profiles FOR UPDATE
  TO authenticated
  USING (public.get_my_role() = 'admin')
  WITH CHECK (public.get_my_role() = 'admin');

-- Allow admins to delete complaints
DROP POLICY IF EXISTS "admin_delete_complaints" ON complaints;
CREATE POLICY "admin_delete_complaints" ON complaints FOR DELETE
  TO authenticated
  USING (public.get_my_role() = 'admin');
